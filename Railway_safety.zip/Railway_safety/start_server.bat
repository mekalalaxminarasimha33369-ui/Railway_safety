@echo off
title SafeRail AI Web Server
echo Starting SafeRail AI Local Server on http://localhost:8080...
cd /d "c:\Users\mekal\OneDrive\Documents\Railway_safety"
start http://localhost:8080
"C:\Program Files\Python314\python.exe" -m http.server 8080 --bind 127.0.0.1
pause
