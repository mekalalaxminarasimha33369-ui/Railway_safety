import React from 'react';
import { AppView } from '../types';
import { PassengerDashboard } from './PassengerDashboard';
import { RpfDashboard } from './RpfDashboard';
import { ControlRoomDashboard } from './ControlRoomDashboard';
import { AdminDashboard } from './AdminDashboard';
import { User, Shield, Radio, Settings, ArrowLeft } from 'lucide-react';

interface DashboardContainerProps {
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  onOpenSos: () => void;
  onOpenQr: () => void;
  onOpenReport: () => void;
}

export const DashboardContainer: React.FC<DashboardContainerProps> = ({
  currentView,
  setCurrentView,
  onOpenSos,
  onOpenQr,
  onOpenReport
}) => {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Navigation Back Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/80 p-4 rounded-2xl border border-slate-800 backdrop-blur-md">
          <button
            onClick={() => setCurrentView('home')}
            className="flex items-center gap-2 text-xs font-bold text-slate-300 hover:text-cyan-400 transition-colors"
          >
            <ArrowLeft size={16} />
            <span>Return to Public Showcase Landing Page</span>
          </button>

          {/* Role Switcher */}
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => setCurrentView('passenger')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                currentView === 'passenger' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <User size={13} />
              <span>Passenger View</span>
            </button>

            <button
              onClick={() => setCurrentView('rpf')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                currentView === 'rpf' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <Shield size={13} />
              <span>RPF Command</span>
            </button>

            <button
              onClick={() => setCurrentView('control_room')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                currentView === 'control_room' ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <Radio size={13} />
              <span>Control Room</span>
            </button>

            <button
              onClick={() => setCurrentView('admin')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                currentView === 'admin' ? 'bg-purple-500 text-slate-950' : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <Settings size={13} />
              <span>Admin Console</span>
            </button>
          </div>
        </div>

        {/* Render View */}
        {currentView === 'passenger' && (
          <PassengerDashboard
            onOpenSos={onOpenSos}
            onOpenQr={onOpenQr}
            onOpenReport={onOpenReport}
          />
        )}
        {currentView === 'rpf' && <RpfDashboard />}
        {currentView === 'control_room' && <ControlRoomDashboard />}
        {currentView === 'admin' && <AdminDashboard />}

      </div>
    </div>
  );
};
