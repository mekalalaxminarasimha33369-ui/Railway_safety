import React, { useState } from 'react';
import { 
  Train, 
  MapPin, 
  ShieldAlert, 
  QrCode, 
  FileText, 
  Bell, 
  User, 
  Clock, 
  CheckCircle2, 
  Activity,
  PhoneCall,
  AlertTriangle,
  ChevronRight
} from 'lucide-react';
import { mockJourney } from '../data/mockData';

interface PassengerDashboardProps {
  onOpenSos: () => void;
  onOpenQr: () => void;
  onOpenReport: () => void;
}

export const PassengerDashboard: React.FC<PassengerDashboardProps> = ({ onOpenSos, onOpenQr, onOpenReport }) => {
  const [activeTab, setActiveTab] = useState<'journey' | 'complaints' | 'profile'>('journey');

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Top Banner Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-railway-blue via-blue-900 to-slate-950 border border-cyan-500/30 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs font-mono font-bold">
              AI SAFETY PROTECTION ACTIVE
            </span>
            <span className="text-xs text-slate-400 font-mono">PNR: {mockJourney.pnr}</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold font-heading text-white">
            Welcome back, <span className="text-cyan-300">Ananya Sharma</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-300">
            Currently onboard <strong className="text-white">{mockJourney.trainNo} {mockJourney.trainName}</strong> &bull; Coach {mockJourney.coach}, Seat {mockJourney.seatNo}
          </p>
        </div>

        {/* SOS Quick Launch Card */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenQr}
            className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 text-teal-400 border border-teal-500/40 font-bold text-xs flex items-center gap-2"
          >
            <QrCode size={18} />
            <span className="hidden sm:inline">My Security QR Pass</span>
          </button>

          <button
            onClick={onOpenSos}
            className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white font-extrabold text-xs shadow-xl shadow-red-600/40 flex items-center gap-2 border border-red-400/40 animate-pulse"
          >
            <ShieldAlert size={20} />
            <span>TRIGGER EMERGENCY SOS</span>
          </button>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('journey')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'journey' ? 'bg-railway-blue text-white' : 'text-slate-400 hover:text-white'
          }`}
        >
          Active Journey Status
        </button>
        <button
          onClick={() => setActiveTab('complaints')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'complaints' ? 'bg-railway-blue text-white' : 'text-slate-400 hover:text-white'
          }`}
        >
          My Incidents & Complaints
        </button>
        <button
          onClick={() => setActiveTab('profile')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'profile' ? 'bg-railway-blue text-white' : 'text-slate-400 hover:text-white'
          }`}
        >
          Emergency Contacts Profile
        </button>
      </div>

      {/* Tab 1: Journey Details */}
      {activeTab === 'journey' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Active Train Journey Card */}
          <div className="lg:col-span-2 space-y-6">
            
            <div className="glass-card p-6 rounded-3xl border border-slate-800 bg-slate-900 space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-2xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                    <Train size={24} />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold font-heading text-white">{mockJourney.trainName} ({mockJourney.trainNo})</h3>
                    <p className="text-xs text-slate-400">Scheduled Express Route</p>
                  </div>
                </div>

                <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 font-mono font-bold text-xs border border-emerald-500/30">
                  ON TIME (98.4% Safety Score)
                </span>
              </div>

              {/* Source vs Destination Timeline */}
              <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-500">Source Station</span>
                  <div className="text-sm font-bold text-white mt-1">{mockJourney.source}</div>
                  <div className="text-[11px] text-slate-400 mt-1">Dep: {mockJourney.departureTime}</div>
                </div>
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-500">Destination</span>
                  <div className="text-sm font-bold text-white mt-1">{mockJourney.destination}</div>
                  <div className="text-[11px] text-slate-400 mt-1">Arr: {mockJourney.arrivalTime}</div>
                </div>
              </div>

              {/* Current Live Location Track Bar */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-500/30 space-y-3">
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="text-slate-400">Current Position:</span>
                  <span className="text-cyan-400 font-bold flex items-center gap-1">
                    <MapPin size={14} />
                    {mockJourney.currentStation}
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-blue-500 via-cyan-400 to-emerald-400 w-3/5"></div>
                </div>
                <div className="flex justify-between text-[10px] font-mono text-slate-500">
                  <span>Next Stop: {mockJourney.nextStation} (ETA 34m)</span>
                  <span>Speed: 110 km/h</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={onOpenReport}
                  className="px-4 py-2.5 rounded-xl bg-orange-500/20 hover:bg-orange-500/30 text-orange-300 font-bold text-xs border border-orange-500/40 flex items-center gap-2"
                >
                  <FileText size={16} />
                  <span>Report Misconduct / Crime</span>
                </button>
                <a
                  href="tel:139"
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold text-xs border border-slate-700 flex items-center gap-2"
                >
                  <PhoneCall size={16} />
                  <span>RPF Helpline 139</span>
                </a>
              </div>
            </div>

          </div>

          {/* Right Column: Onboard RPF Escort Squad Info */}
          <div className="space-y-6">
            <div className="glass-card p-6 rounded-3xl border border-slate-800 bg-slate-900 space-y-4">
              <h3 className="text-base font-bold font-heading text-white flex items-center gap-2">
                <ShieldAlert size={18} className="text-amber-400" />
                <span>Onboard RPF Security Unit</span>
              </h3>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>Squad Leader:</span>
                  <span className="text-white font-bold">Insp. Vikram Singh</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>RPF Station Post:</span>
                  <span className="text-slate-200">Kanpur Division</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Assigned Coaches:</span>
                  <span className="text-cyan-400 font-bold">B1 to B6</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Night Patrol Duty:</span>
                  <span className="text-emerald-400 font-bold">ACTIVE (22:00 - 06:00)</span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-cyan-950/40 border border-cyan-800/40 text-xs text-cyan-200 flex items-center gap-2">
                <Activity size={16} className="text-cyan-400 animate-spin" />
                <span>AI Camera Nodes in B4 Coach Streaming Live</span>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* Tab 2: Complaints */}
      {activeTab === 'complaints' && (
        <div className="glass-card p-6 rounded-3xl border border-slate-800 bg-slate-900 space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-bold text-white">Recent Submitted Incident Tickets</h3>
            <button
              onClick={onOpenReport}
              className="px-4 py-2 rounded-xl bg-orange-500 text-white text-xs font-bold"
            >
              + File New Ticket
            </button>
          </div>

          <div className="space-y-3">
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex justify-between items-center text-xs">
              <div>
                <div className="font-bold text-white">TKT-8941: Missing Handbag near Restroom</div>
                <div className="text-slate-400 mt-0.5">Filed: 2 days ago &bull; Train 12423</div>
              </div>
              <span className="px-3 py-1 rounded bg-emerald-500/20 text-emerald-400 font-mono font-bold">
                RESOLVED BY RPF
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Emergency Profile */}
      {activeTab === 'profile' && (
        <div className="glass-card p-6 rounded-3xl border border-slate-800 bg-slate-900 space-y-4">
          <h3 className="text-lg font-bold text-white">Emergency Contacts & Medical Info</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="text-slate-400">Primary Contact (Father)</div>
              <div className="text-white font-bold mt-1">Rajesh Sharma (+91 98765 43210)</div>
            </div>
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="text-slate-400">Medical Condition / Allergies</div>
              <div className="text-rose-400 font-bold mt-1">Asthma / O+ Blood Group</div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
