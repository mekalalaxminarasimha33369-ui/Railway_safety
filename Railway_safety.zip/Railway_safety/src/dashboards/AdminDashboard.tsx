import React from 'react';
import { Settings, Cpu, ShieldCheck, Database, FileText, SlidersHorizontal, Activity } from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Header */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-slate-950 via-purple-950/40 to-slate-950 border border-purple-500/40 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <span className="px-3 py-1 rounded-full bg-purple-500/20 text-purple-400 font-mono font-bold text-xs border border-purple-500/40">
            SYSTEM ADMIN & AI CONFIGURATION
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-heading text-white mt-2">
            SafeRail System Console
          </h1>
          <p className="text-xs text-slate-400">
            Model Hyperparameters &bull; Role Access Policy &bull; DPDP Compliance Logs
          </p>
        </div>
      </div>

      {/* Admin Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card p-6 rounded-3xl border border-slate-800 bg-slate-900 space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-purple-500/20 text-purple-400">
              <Cpu size={22} />
            </div>
            <h3 className="text-base font-bold text-white">YOLOv8 Weights Config</h3>
          </div>
          <div className="space-y-2 text-xs font-mono text-slate-400">
            <div className="flex justify-between">
              <span>Confidence Threshold:</span>
              <span className="text-white font-bold">0.85</span>
            </div>
            <div className="flex justify-between">
              <span>NMS IoU Threshold:</span>
              <span className="text-white font-bold">0.45</span>
            </div>
            <div className="flex justify-between">
              <span>Frame Sampling:</span>
              <span className="text-cyan-400 font-bold">30 FPS</span>
            </div>
          </div>
        </div>

        <div className="glass-card p-6 rounded-3xl border border-slate-800 bg-slate-900 space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-cyan-500/20 text-cyan-400">
              <Database size={22} />
            </div>
            <h3 className="text-base font-bold text-white">Database Shards</h3>
          </div>
          <div className="space-y-2 text-xs font-mono text-slate-400">
            <div className="flex justify-between">
              <span>Primary Node:</span>
              <span className="text-emerald-400 font-bold">ACTIVE</span>
            </div>
            <div className="flex justify-between">
              <span>Geo Index Sync:</span>
              <span className="text-white font-bold">100%</span>
            </div>
            <div className="flex justify-between">
              <span>Storage Used:</span>
              <span className="text-purple-300 font-bold">14.2 TB</span>
            </div>
          </div>
        </div>

        <div className="glass-card p-6 rounded-3xl border border-slate-800 bg-slate-900 space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-emerald-500/20 text-emerald-400">
              <ShieldCheck size={22} />
            </div>
            <h3 className="text-base font-bold text-white">DPDP Audit Security</h3>
          </div>
          <div className="space-y-2 text-xs font-mono text-slate-400">
            <div className="flex justify-between">
              <span>Anonymization Hash:</span>
              <span className="text-emerald-400 font-bold">PASSED</span>
            </div>
            <div className="flex justify-between">
              <span>Access Control:</span>
              <span className="text-white font-bold">RBAC Enforced</span>
            </div>
            <div className="flex justify-between">
              <span>Log Encryption:</span>
              <span className="text-cyan-400 font-bold">AES-256</span>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};
