import React, { useState } from 'react';
import { 
  Radio, 
  Eye, 
  MapPin, 
  ShieldCheck, 
  Activity, 
  Video, 
  Building2, 
  Train, 
  AlertTriangle,
  Grid
} from 'lucide-react';
import { mockCctvFeeds } from '../data/mockData';

export const ControlRoomDashboard: React.FC = () => {
  const [selectedCam, setSelectedCam] = useState(mockCctvFeeds[0]);

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* National Command Header */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-emerald-500/40 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
            <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 font-mono font-bold text-xs border border-emerald-500/40">
              NATIONAL RAILWAY SAFETY COMMAND CENTER
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-heading text-white mt-2">
            Pan-India Live Control Room
          </h1>
          <p className="text-xs text-slate-400">
            750+ Junctions Monitored &bull; 18 Zone Telemetry Mesh &bull; Edge CCTV Neural Net
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-right">
            <div className="text-slate-500">CCTV STREAMS</div>
            <div className="text-emerald-400 font-bold text-lg">12,450 ACTIVE</div>
          </div>
          <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-right">
            <div className="text-slate-500">SYSTEM HEALTH</div>
            <div className="text-cyan-400 font-bold text-lg">99.98% UPTIME</div>
          </div>
        </div>
      </div>

      {/* Main Command Center Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* CCTV Camera Feeds Grid */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold font-heading text-white flex items-center gap-2">
              <Video size={18} className="text-emerald-400" />
              <span>Live Multi-Camera Neural Net Matrix</span>
            </h3>
            <span className="text-xs font-mono text-cyan-400 font-bold">YOLOv8 Edge Inference Active</span>
          </div>

          {/* Active Featured CCTV Feed Box */}
          <div className="h-72 rounded-3xl bg-slate-950 border border-emerald-500/40 relative overflow-hidden flex flex-col justify-between p-4 shadow-2xl">
            <div className="flex items-center justify-between z-10 text-xs font-mono">
              <span className="px-3 py-1 rounded bg-slate-900/90 text-emerald-400 font-bold border border-emerald-500/30 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                {selectedCam.stationOrTrain}
              </span>
              <span className="text-slate-400">{selectedCam.cameraLocation} &bull; {selectedCam.fps} FPS</span>
            </div>

            {/* AI Threat Anomaly Overlay */}
            {selectedCam.aiAlert && (
              <div className="z-10 p-3 rounded-xl bg-amber-500/20 border border-amber-500 text-amber-300 text-xs font-mono animate-pulse max-w-md mx-auto text-center">
                <AlertTriangle size={18} className="inline mr-1" />
                <span>AI ALERT: {selectedCam.aiAlert}</span>
              </div>
            )}

            <div className="z-10 flex items-center justify-between text-xs font-mono bg-slate-900/90 p-3 rounded-2xl border border-slate-800">
              <span className="text-slate-300">Monitored People Count: <strong className="text-cyan-400">{selectedCam.peopleCount}</strong></span>
              <span className="text-slate-300">Threat Index: <strong className={selectedCam.threatLevel === 'High' ? 'text-rose-400 font-bold' : 'text-emerald-400'}>{selectedCam.threatLevel}</strong></span>
            </div>
          </div>

          {/* Camera Selection List */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {mockCctvFeeds.map((feed) => (
              <button
                key={feed.id}
                onClick={() => setSelectedCam(feed)}
                className={`p-3 rounded-2xl border text-left text-xs font-mono transition-all ${
                  selectedCam.id === feed.id
                    ? 'bg-slate-900 border-emerald-400 text-white shadow-md'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="font-bold truncate text-[11px]">{feed.id}</div>
                <div className="text-[10px] text-slate-500 truncate mt-0.5">{feed.stationOrTrain.split('-')[0]}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Right Column: Pan-India Station Alert Ticker */}
        <div className="space-y-6">
          <div className="glass-card p-6 rounded-3xl border border-slate-800 bg-slate-900 space-y-4">
            <h3 className="text-base font-bold font-heading text-white flex items-center gap-2">
              <Radio size={18} className="text-cyan-400" />
              <span>Pan-India Zone Status Ticker</span>
            </h3>

            <div className="space-y-3 font-mono text-xs">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
                <span>Northern Railway (NDLS)</span>
                <span className="text-emerald-400 font-bold">NORMAL</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
                <span>Western Railway (CSMT)</span>
                <span className="text-emerald-400 font-bold">NORMAL</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
                <span>Eastern Railway (HWH)</span>
                <span className="text-amber-400 font-bold">HIGH RUSH</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
                <span>Southern Railway (MAS)</span>
                <span className="text-emerald-400 font-bold">NORMAL</span>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
