import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Clock, 
  MapPin, 
  UserCheck, 
  Radio, 
  CheckCircle, 
  AlertTriangle, 
  PhoneCall, 
  Train, 
  Activity,
  Send,
  Navigation
} from 'lucide-react';
import { mockEmergencyAlerts } from '../data/mockData';
import { EmergencyAlert } from '../types';

export const RpfDashboard: React.FC = () => {
  const [alerts, setAlerts] = useState<EmergencyAlert[]>(mockEmergencyAlerts);
  const [selectedAlert, setSelectedAlert] = useState<EmergencyAlert>(mockEmergencyAlerts[0]);

  const handleResolveAlert = (id: string) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, status: 'RESOLVED' } : a));
    if (selectedAlert.id === id) {
      setSelectedAlert(prev => ({ ...prev, status: 'RESOLVED' }));
    }
  };

  const handleDispatchUnit = (id: string) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, status: 'DISPATCHED' } : a));
    if (selectedAlert.id === id) {
      setSelectedAlert(prev => ({ ...prev, status: 'DISPATCHED' }));
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Top RPF Header */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-amber-950/40 to-slate-950 border border-amber-500/40 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-400 font-mono font-bold text-xs border border-amber-500/40">
              RPF TACTICAL COMMAND PORTAL
            </span>
            <span className="text-xs text-slate-400 font-mono">NORTHERN RAILWAY DIVISION</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-heading text-white mt-1">
            Inspector General Command Console
          </h1>
          <p className="text-xs text-slate-400">
            Real-time SOS Dispatch &bull; Automated Geo-Fencing &bull; Live Telemetry Feed
          </p>
        </div>

        {/* Stats Metrics Header Pills */}
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-rose-950/60 border border-rose-800 text-center min-w-28">
            <div className="text-[10px] font-mono text-rose-300">ACTIVE CRITICAL</div>
            <div className="text-xl font-bold font-mono text-white">03 ALERTS</div>
          </div>
          <div className="p-3 rounded-2xl bg-amber-950/60 border border-amber-800 text-center min-w-28">
            <div className="text-[10px] font-mono text-amber-300">AVG RESPONSE</div>
            <div className="text-xl font-bold font-mono text-white">02m 14s</div>
          </div>
        </div>
      </div>

      {/* Main Command Console Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Live Incident Queue */}
        <div className="space-y-4">
          <div className="flex justify-between items-center px-1">
            <h3 className="text-base font-bold font-heading text-white flex items-center gap-2">
              <ShieldAlert size={18} className="text-rose-400 animate-pulse" />
              <span>Incoming Emergency SOS Queue</span>
            </h3>
            <span className="text-xs font-mono text-slate-400">{alerts.length} Total Logs</span>
          </div>

          <div className="space-y-3">
            {alerts.map((alert) => {
              const isSelected = selectedAlert.id === alert.id;
              return (
                <div
                  key={alert.id}
                  onClick={() => setSelectedAlert(alert)}
                  className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-900 border-amber-400 shadow-lg shadow-amber-500/10'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-xs font-bold text-slate-300">{alert.id}</span>
                    <span className={`px-2.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                      alert.status === 'CRITICAL' ? 'bg-rose-600 text-white animate-pulse' :
                      alert.status === 'DISPATCHED' ? 'bg-amber-500 text-slate-950' :
                      alert.status === 'ON_SITE' ? 'bg-cyan-500 text-slate-950' :
                      'bg-emerald-500/20 text-emerald-400'
                    }`}>
                      {alert.status}
                    </span>
                  </div>

                  <div className="text-sm font-bold text-white mb-1">{alert.type}: {alert.passengerName}</div>
                  <div className="text-xs text-slate-400">
                    Train {alert.trainNo} ({alert.trainName}) &bull; Coach {alert.coach}, Seat {alert.seat}
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[10px] font-mono text-slate-500">
                    <span>{alert.timestamp}</span>
                    <span className="text-cyan-400 font-bold">AI Confidence: {alert.confidence}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Center & Right Column: Incident Detail & Tactical Dispatch Controls */}
        <div className="lg:col-span-2 space-y-6">
          
          <div className="glass-card p-6 sm:p-8 rounded-3xl border border-slate-800 bg-slate-900 space-y-6">
            
            {/* Header Detail */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-amber-400">INCIDENT DOSSIER</span>
                  <span className="text-xs font-mono text-slate-500">|</span>
                  <span className="text-xs font-mono text-cyan-400">REF: {selectedAlert.id}</span>
                </div>
                <h2 className="text-2xl font-bold font-heading text-white mt-1">
                  {selectedAlert.type} Alert &bull; {selectedAlert.passengerName}
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Contact: <span className="text-white font-mono">{selectedAlert.phone}</span>
                </p>
              </div>

              <div className="flex items-center gap-2">
                {selectedAlert.status !== 'RESOLVED' && (
                  <button
                    onClick={() => handleDispatchUnit(selectedAlert.id)}
                    className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md"
                  >
                    Dispatch Squad Unit
                  </button>
                )}
                {selectedAlert.status !== 'RESOLVED' && (
                  <button
                    onClick={() => handleResolveAlert(selectedAlert.id)}
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md"
                  >
                    Mark Ticket Resolved
                  </button>
                )}
              </div>
            </div>

            {/* Carriage & GPS Coordinates Card */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
                <span className="text-slate-500">Target Carriage</span>
                <div className="text-base font-bold text-white mt-1">Coach {selectedAlert.coach} - Seat {selectedAlert.seat}</div>
                <div className="text-[10px] text-slate-400 mt-1">Train {selectedAlert.trainNo}</div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
                <span className="text-slate-500">Geo Telemetry</span>
                <div className="text-base font-bold text-cyan-400 mt-1">{selectedAlert.lat}, {selectedAlert.lng}</div>
                <div className="text-[10px] text-slate-400 mt-1">{selectedAlert.location}</div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
                <span className="text-slate-500">Dispatch Response Timer</span>
                <div className="text-base font-bold text-rose-400 mt-1">01m 48s Elapsed</div>
                <div className="text-[10px] text-emerald-400 mt-1">Target: &lt; 03m 00s</div>
              </div>
            </div>

            {/* Simulated Live Tactical Map Frame */}
            <div className="h-56 rounded-2xl bg-slate-950 border border-cyan-500/30 relative overflow-hidden flex flex-col justify-between p-4">
              <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 z-10">
                <span className="flex items-center gap-1 text-cyan-400 font-bold">
                  <Navigation size={12} className="animate-spin" />
                  LIVE RPF SQUAD GEO-ROUTING MAP
                </span>
                <span>KANPUR DIVISION SECTOR 4</span>
              </div>

              <div className="z-10 text-center">
                <MapPin size={32} className="text-rose-500 mx-auto animate-bounce" />
                <div className="font-mono text-xs font-bold text-white mt-1">
                  Target Coach B4 Positioning: KM 412
                </div>
                <div className="font-mono text-[10px] text-cyan-400">
                  Onboard Squad #4 is 12 meters away in Coach B3 Corridor
                </div>
              </div>

              <div className="z-10 flex justify-between text-[10px] font-mono text-slate-500">
                <span>Signal: Encrypted Satellite Stream</span>
                <span>Accuracy: &lt; 0.5 meters</span>
              </div>
            </div>

          </div>

        </div>

      </div>

    </div>
  );
};
