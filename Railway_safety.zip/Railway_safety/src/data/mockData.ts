import { EmergencyAlert, JourneyDetails, CctvFeed, AiModuleItem, FeatureItem, TestimonialItem, FaqItem } from '../types';

export const mockJourney: JourneyDetails = {
  pnr: "4528910342",
  trainNo: "12423",
  trainName: "RAJDHANI EXPRESS",
  source: "New Delhi (NDLS)",
  destination: "Dibrugarh (DBRG)",
  coach: "B4",
  seatNo: "32 (Side Lower)",
  departureTime: "16:10",
  arrivalTime: "04:30 +1 Day",
  currentStation: "Kanpur Central (CNB)",
  nextStation: "Prayagraj Junction (PRYJ)",
  status: "ON_TIME",
  safetyScore: 98.4
};

export const mockEmergencyAlerts: EmergencyAlert[] = [
  {
    id: "ALT-9042",
    passengerName: "Ananya Sharma",
    phone: "+91 98765 43210",
    trainNo: "12423",
    trainName: "Rajdhani Express",
    coach: "B4",
    seat: "32",
    location: "KM 412 near Kanpur Central",
    lat: 26.4499,
    lng: 80.3319,
    timestamp: "2 mins ago",
    type: "Women Security",
    status: "CRITICAL",
    confidence: 97.8,
    aiDetected: true
  },
  {
    id: "ALT-9041",
    passengerName: "Rajesh Kumar",
    phone: "+91 98111 22334",
    trainNo: "12951",
    trainName: "Mumbai Rajdhani",
    coach: "A2",
    seat: "15",
    location: "Kota Junction (KOTA)",
    lat: 25.2138,
    lng: 75.8648,
    timestamp: "7 mins ago",
    type: "Medical",
    status: "DISPATCHED",
    confidence: 94.2,
    aiDetected: false
  },
  {
    id: "ALT-9040",
    passengerName: "Priya Nair",
    phone: "+91 99887 76655",
    trainNo: "22436",
    trainName: "Vande Bharat Express",
    coach: "C7",
    seat: "48",
    location: "Varanasi Junction (BSB)",
    lat: 25.3176,
    lng: 82.9739,
    timestamp: "18 mins ago",
    type: "Theft/Crime",
    status: "ON_SITE",
    confidence: 99.1,
    aiDetected: true
  },
  {
    id: "ALT-9039",
    passengerName: "Sunita Verma",
    phone: "+91 97654 32109",
    trainNo: "12301",
    trainName: "Howrah Rajdhani",
    coach: "H1",
    seat: "08",
    location: "Dhanbad Junction (DHN)",
    lat: 23.7957,
    lng: 86.4304,
    timestamp: "32 mins ago",
    type: "Child Safety",
    status: "RESOLVED",
    confidence: 91.5,
    aiDetected: true
  }
];

export const mockCctvFeeds: CctvFeed[] = [
  {
    id: "CAM-NDLS-P1-04",
    stationOrTrain: "New Delhi Station - Platform 1",
    cameraLocation: "Main Concourse North",
    status: "ALERT",
    aiAlert: "Unattended Luggage Detected (>8 mins)",
    peopleCount: 142,
    threatLevel: "High",
    fps: 30
  },
  {
    id: "CAM-TB-12423-B4",
    stationOrTrain: "Train 12423 - Coach B4",
    cameraLocation: "Passageway Near Door 2",
    status: "WARNING",
    aiAlert: "Distress Vocal Frequency Detected",
    peopleCount: 18,
    threatLevel: "Medium",
    fps: 25
  },
  {
    id: "CAM-CSMT-P4-01",
    stationOrTrain: "Mumbai CSMT - Platform 4",
    cameraLocation: "VIP Escalator Entrance",
    status: "ACTIVE",
    peopleCount: 89,
    threatLevel: "Low",
    fps: 30
  },
  {
    id: "CAM-HWH-MAIN-02",
    stationOrTrain: "Howrah Junction - Main Gate",
    cameraLocation: "Ticket Counter Hall",
    status: "ACTIVE",
    peopleCount: 210,
    threatLevel: "Low",
    fps: 30
  }
];

export const mockFeatures: FeatureItem[] = [
  {
    id: "f1",
    title: "AI Surveillance Grid",
    category: "AI Surveillance",
    description: "Real-time facial recognition, anomaly detection, and weapon tracking using onboard and station cameras.",
    iconName: "Eye",
    gradient: "from-blue-600 to-cyan-500",
    badge: "AI Powered"
  },
  {
    id: "f2",
    title: "SOS Emergency Button",
    category: "Passenger",
    description: "One-tap emergency trigger broadcasting live GPS coordinates, carriage seat details, and audio feed to RPF.",
    iconName: "AlertTriangle",
    gradient: "from-red-600 to-orange-500",
    badge: "Instant Response"
  },
  {
    id: "f3",
    title: "Live Precision GPS Tracking",
    category: "Passenger",
    description: "Real-time train positioning synced with geo-fenced RPF squad locations along the rail corridor.",
    iconName: "MapPin",
    gradient: "from-emerald-600 to-teal-500"
  },
  {
    id: "f4",
    title: "Face Recognition & Blacklist",
    category: "AI Surveillance",
    description: "Instant matching against national crime databases to alert station guards of known offenders.",
    iconName: "ScanFace",
    gradient: "from-purple-600 to-indigo-500",
    badge: "YOLOv8 + OpenCV"
  },
  {
    id: "f5",
    title: "Voice-Activated SOS",
    category: "Safety",
    description: "Hands-free emergency activation triggered by trigger keywords (e.g., 'Help Me SafeRail') during distress.",
    iconName: "Mic",
    gradient: "from-amber-500 to-red-500"
  },
  {
    id: "f6",
    title: "Medical Emergency Assistance",
    category: "Passenger",
    description: "Instant notification to the nearest station doctor and automatic dispatch of medical kits to coach doors.",
    iconName: "HeartPulse",
    gradient: "from-rose-600 to-pink-500"
  },
  {
    id: "f7",
    title: "AI Lost & Found Matcher",
    category: "Passenger",
    description: "Upload photos of missing items or relatives; computer vision scans national station logs for instant hits.",
    iconName: "Search",
    gradient: "from-blue-500 to-indigo-500"
  },
  {
    id: "f8",
    title: "Women & Child Dedicated Safety",
    category: "Safety",
    description: "Specialized night travel escort tracking, automated coach lighting verification, and female RPF alerts.",
    iconName: "ShieldCheck",
    gradient: "from-pink-600 to-rose-500",
    badge: "Priority"
  },
  {
    id: "f9",
    title: "Crime Reporting Portal",
    category: "Passenger",
    description: "File anonymous crime, harassment, or theft reports with photo evidence direct to Division Security Control.",
    iconName: "FileText",
    gradient: "from-orange-500 to-amber-600"
  },
  {
    id: "f10",
    title: "RPF Tactical Dashboard",
    category: "RPF",
    description: "Real-time incident queue, live station maps, automated unit dispatching, and response timer metrics.",
    iconName: "ShieldAlert",
    gradient: "from-blue-700 to-blue-900",
    badge: "Command Portal"
  },
  {
    id: "f11",
    title: "Heatmap Threat Analytics",
    category: "AI Surveillance",
    description: "Predictive spatial mapping of vulnerable sections, peak crime times, and high-density station areas.",
    iconName: "Activity",
    gradient: "from-cyan-600 to-blue-600"
  },
  {
    id: "f12",
    title: "Smart Offline Emergency Mode",
    category: "Safety",
    description: "Uses encrypted SMS mesh and Bluetooth beacon technology when cellular data connectivity drops in tunnels.",
    iconName: "WifiOff",
    gradient: "from-slate-600 to-gray-800",
    badge: "Offline Ready"
  },
  {
    id: "f13",
    title: "QR Emergency Security Identity",
    category: "Passenger",
    description: "Generate a tamper-proof QR code with PNR verification, emergency contacts, and blood group info.",
    iconName: "QrCode",
    gradient: "from-emerald-500 to-cyan-600"
  },
  {
    id: "f14",
    title: "RailRakshak AI Chat Assistant",
    category: "AI Surveillance",
    description: "24/7 multilingual conversational bot answering safety queries, tracking complaints, and guiding SOS.",
    iconName: "Bot",
    gradient: "from-blue-600 to-purple-600"
  },
  {
    id: "f15",
    title: "Predictive Crime Analysis",
    category: "AI Surveillance",
    description: "Machine learning model predicting potential threat hotspots based on historical train route telemetry.",
    iconName: "BrainCircuit",
    gradient: "from-indigo-600 to-purple-700"
  },
  {
    id: "f16",
    title: "Journey Companion Escort",
    category: "Safety",
    description: "Share live journey milestones automatically with family members with unexpected delay alerts.",
    iconName: "Navigation",
    gradient: "from-teal-600 to-emerald-600"
  }
];

export const mockAiModules: AiModuleItem[] = [
  {
    id: "ai-1",
    title: "Smart Threat & Anomaly Detection",
    category: "Vision",
    description: "Continuous spatial parsing of CCTV feeds identifying erratic crowd movement, sudden running, and physical altercations.",
    icon: "ShieldAlert",
    accuracy: "99.2%",
    latency: "<45ms",
    tech: "YOLOv8 + OpenCV + PyTorch"
  },
  {
    id: "ai-2",
    title: "Weapon & Hazardous Object Detection",
    category: "Vision",
    description: "X-Ray scanner integration and luggage camera AI models trained on 500,000+ threat objects.",
    icon: "Crosshair",
    accuracy: "98.7%",
    latency: "<30ms",
    tech: "TensorFlow RT + CUDA Engine"
  },
  {
    id: "ai-3",
    title: "Unattended & Abandoned Luggage Tracking",
    category: "Vision",
    description: "Temporal object persistence algorithms monitoring un-owned bags past safety thresholds (e.g. 5 mins).",
    icon: "Briefcase",
    accuracy: "97.9%",
    latency: "<100ms",
    tech: "DeepSORT + ResNet50"
  },
  {
    id: "ai-4",
    title: "Audio Vocal Distress Analysis",
    category: "Audio",
    description: "Acoustic frequency sensors in coach corridors identifying screams, glass breaks, and high-decibel shouting.",
    icon: "Volume2",
    accuracy: "96.4%",
    latency: "<15ms",
    tech: "MFCC + CNN Audio Classification"
  },
  {
    id: "ai-5",
    title: "Predictive Route Risk Scoring",
    category: "Predictive",
    description: "Spatial-temporal machine learning model assigning live danger indices to train sections and night stops.",
    icon: "TrendingUp",
    accuracy: "95.8%",
    latency: "Real-time Batch",
    tech: "XGBoost + GeoPandas"
  },
  {
    id: "ai-6",
    title: "RailRakshak Multilingual NLP Assistant",
    category: "NLP",
    description: "LLM fine-tuned on Indian Railways security protocols, supporting 12 Indian languages for instant voice interaction.",
    icon: "MessageSquare",
    accuracy: "99.0%",
    latency: "<200ms",
    tech: "OpenAI GPT-4o / Fine-tuned Llama-3"
  }
];

export const mockTestimonials: TestimonialItem[] = [
  {
    id: "t1",
    name: "Shri Rajeshwar Verma",
    role: "Inspector General",
    organization: "Railway Protection Force (RPF), Northern Railway",
    quote: "SafeRail AI has revolutionized our emergency response time. What previously took 15 minutes to relay through control rooms is now instantaneous. The live GPS coach tracking is a game-changer for officer safety.",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80",
    rating: 5
  },
  {
    id: "t2",
    name: "Meenakshi Sundaram",
    role: "Frequent Solo Traveller",
    organization: "IT Architect, Bengaluru",
    quote: "Traveling overnight in trains used to give my family anxiety. With SafeRail AI's Women Escort Mode and instant voice SOS, I feel 100% secure. The QR emergency identity card is brilliant!",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80",
    rating: 5
  },
  {
    id: "t3",
    name: "Dr. K. S. Mukherjee",
    role: "Chief Medical Officer",
    organization: "Eastern Railway Divisional Hospital",
    quote: "The medical emergency alert system allowed our emergency team to meet Train 12301 at the platform with cardiac equipment ready before the train stopped, saving a passenger's life.",
    avatar: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=200&q=80",
    rating: 5
  }
];

export const mockFaqs: FaqItem[] = [
  {
    id: "faq-1",
    category: "Emergency & SOS",
    question: "How does the SOS Emergency Trigger work in real time?",
    answer: "When a passenger presses the SOS button or utters the voice trigger phrase, SafeRail AI instantly broadcasts the passenger's exact carriage (Train No, Coach B4, Seat 32), live GPS coordinates, and a 10-second encrypted audio clip directly to the nearest RPF patrol team, train conductor, and control room."
  },
  {
    id: "faq-2",
    category: "Security & Privacy",
    question: "How is passenger data and privacy protected during AI surveillance?",
    answer: "SafeRail AI operates under strict Digital Personal Data Protection (DPDP) compliance. Facial recognition data on station feeds is processed locally at the edge and instantly anonymized into cryptographic hashes. Facial matching only triggers alerts against authorized national criminal databases."
  },
  {
    id: "faq-3",
    category: "AI & Technology",
    question: "How does the AI detect threats inside running trains?",
    answer: "Onboard edge-AI nodes process wide-angle camera feeds and acoustic sensors. YOLOv8 models analyze pose estimations for physical violence, abandoned objects, and weapons, while acoustic models detect scream frequencies without recording private conversations."
  },
  {
    id: "faq-4",
    category: "Connectivity",
    question: "Can the SOS system function in remote areas or tunnels without internet?",
    answer: "Yes! SafeRail AI includes an Offline Emergency Mesh. When 4G/5G data drops, the app switches automatically to encrypted offline SMS relay and short-range Bluetooth beaconing between adjacent coach receivers, ensuring your distress message always reaches the train guard."
  },
  {
    id: "faq-5",
    category: "RPF & Law Enforcement",
    question: "Who receives the emergency alerts and what is the target response time?",
    answer: "Alerts are received simultaneously by: 1) Escort RPF staff on board the train, 2) The Train Superintendent / Guard, 3) Station Security Control at the upcoming station, and 4) Pre-configured family emergency contacts. Standard target response time on board is under 3 minutes."
  }
];
