import React, { useState } from 'react';
import { 
  UserCheck, 
  Train, 
  Cpu, 
  AlertTriangle, 
  Bell, 
  MapPin, 
  ShieldCheck, 
  CheckCircle2,
  ChevronRight
} from 'lucide-react';

export const HowItWorks: React.FC = () => {
  const [activeStep, setActiveStep] = useState<number>(3);

  const steps = [
    {
      step: 1,
      title: "Passenger logs into SafeRail App",
      desc: "Passenger links PNR or boards train. System activates personalized emergency profile and journey safety metrics.",
      icon: UserCheck,
      color: "text-blue-400"
    },
    {
      step: 2,
      title: "Journey Starts & Geo-Fence Active",
      desc: "Live GPS train tracking pairs passenger mobile location with coach and upcoming RPF division stations.",
      icon: Train,
      color: "text-cyan-400"
    },
    {
      step: 3,
      title: "AI Continuously Monitors",
      desc: "Edge-AI nodes analyze CCTV feeds for erratic movement, overcrowding, abandoned objects, and distress acoustic signals.",
      icon: Cpu,
      color: "text-purple-400"
    },
    {
      step: 4,
      title: "Threat / Emergency Detected",
      desc: "System identifies anomaly or passenger activates one-tap SOS / voice trigger keyword ('Help Me SafeRail').",
      icon: AlertTriangle,
      color: "text-rose-400"
    },
    {
      step: 5,
      title: "SOS Triggered & Encrypted",
      desc: "High-priority emergency payload (Train 12423, B4-32, Audio clip, GPS) packaged with cryptographic verification.",
      icon: Bell,
      color: "text-amber-400"
    },
    {
      step: 6,
      title: "Live Location & Audio Shared",
      desc: "Real-time socket connection streams continuous GPS coordinates to nearest on-duty RPF officers.",
      icon: MapPin,
      color: "text-emerald-400"
    },
    {
      step: 7,
      title: "Railway Police (RPF) Notified",
      desc: "Onboard escort squad receives tablet alert with coach entry route; Station control prepares platform response.",
      icon: ShieldCheck,
      color: "text-indigo-400"
    },
    {
      step: 8,
      title: "Emergency Resolved & Verified",
      desc: "RPF officer reaches coach door in <3 mins, secures area, verifies passenger safety, and closes dispatch ticket.",
      icon: CheckCircle2,
      color: "text-teal-400"
    }
  ];

  return (
    <section id="how-it-works" className="py-20 bg-slate-900 relative">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="px-3.5 py-1.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30 text-xs font-semibold uppercase tracking-wider">
            Seamless Autonomous Workflow
          </span>
          <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight">
            How <span className="text-amber-400">SafeRail AI</span> Works
          </h2>
          <p className="mt-4 text-base text-slate-400">
            An end-to-end autonomous lifecycle that connects passenger mobile devices, onboard AI cameras, and RPF tactical units.
          </p>
        </div>

        {/* Horizontal / Grid Step Visualizer */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((item) => {
            const Icon = item.icon;
            const isActive = activeStep === item.step;

            return (
              <div
                key={item.step}
                onClick={() => setActiveStep(item.step)}
                className={`glass-card p-6 rounded-3xl border cursor-pointer transition-all duration-300 relative overflow-hidden flex flex-col justify-between ${
                  isActive 
                    ? 'border-amber-400/80 bg-slate-800/90 shadow-xl shadow-amber-500/10 scale-102' 
                    : 'border-slate-800 hover:border-slate-700 bg-slate-950/60'
                }`}
              >
                {/* Step Pill */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className={`w-8 h-8 rounded-xl font-mono text-xs font-extrabold flex items-center justify-center ${
                      isActive ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-400'
                    }`}>
                      0{item.step}
                    </span>
                    <Icon className={item.color} size={22} />
                  </div>

                  <h3 className={`text-base font-bold font-heading mb-2 ${isActive ? 'text-amber-300' : 'text-white'}`}>
                    {item.title}
                  </h3>

                  <p className="text-xs text-slate-400 leading-relaxed">
                    {item.desc}
                  </p>
                </div>

                {/* Arrow indicator */}
                <div className="mt-6 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-400">
                  <span>Step {item.step} of 8</span>
                  <ChevronRight size={14} className={isActive ? 'text-amber-400 animate-pulse' : 'text-slate-600'} />
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Step Active Detail Highlight */}
        <div className="mt-12 p-6 rounded-3xl bg-slate-950 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-2xl">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center shrink-0">
              {React.createElement(steps[activeStep - 1].icon, { size: 28 })}
            </div>
            <div>
              <div className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider">
                Active Step Simulation
              </div>
              <h4 className="text-lg font-bold text-white mt-0.5">
                Step {activeStep}: {steps[activeStep - 1].title}
              </h4>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                {steps[activeStep - 1].desc}
              </p>
            </div>
          </div>
          <button 
            onClick={() => setActiveStep(activeStep < 8 ? activeStep + 1 : 1)}
            className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs shrink-0 flex items-center gap-1.5 shadow-lg shadow-amber-400/20"
          >
            <span>Next Step ({activeStep < 8 ? activeStep + 1 : 1}/8)</span>
            <ChevronRight size={14} />
          </button>
        </div>

      </div>
    </section>
  );
};
