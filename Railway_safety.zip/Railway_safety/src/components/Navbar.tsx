import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Train, 
  Menu, 
  X, 
  Sun, 
  Moon, 
  Activity, 
  PhoneCall, 
  LayoutDashboard, 
  User, 
  Shield, 
  Settings, 
  Radio
} from 'lucide-react';
import { AppView } from '../types';

interface NavbarProps {
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean) => void;
  onOpenSos: () => void;
  onOpenChat: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  setCurrentView,
  isDarkMode,
  setIsDarkMode,
  onOpenSos,
  onOpenChat
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Overview', href: '#hero', view: 'home' as AppView },
    { label: 'Features', href: '#features', view: 'home' as AppView },
    { label: 'How It Works', href: '#how-it-works', view: 'home' as AppView },
    { label: 'AI Engine', href: '#ai-modules', view: 'home' as AppView },
    { label: 'Analytics', href: '#analytics', view: 'home' as AppView },
    { label: 'Architecture', href: '#architecture', view: 'home' as AppView },
  ];

  const handleNavClick = (view: AppView, href?: string) => {
    setCurrentView(view);
    setMobileMenuOpen(false);
    if (href && view === 'home') {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full transition-all duration-300">
      {/* Top Govt / SIH Strip */}
      <div className="bg-gradient-to-r from-railway-darker via-railway-navy to-railway-darker text-xs text-slate-300 py-1.5 px-4 border-b border-white/10 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 font-semibold text-railway-cyan">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            INDIAN RAILWAYS &bull; GOVERNMENT OF INDIA
          </span>
          <span className="hidden md:inline-block text-slate-500">|</span>
          <span className="hidden md:inline-block text-amber-400 font-medium">
            Smart India Hackathon (SIH) Flagship Innovation
          </span>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={onOpenChat}
            className="flex items-center gap-1 hover:text-railway-cyan transition-colors"
          >
            <Activity size={13} className="text-railway-cyan" />
            <span className="hidden sm:inline">AI Help Assistant</span>
          </button>
          <a href="tel:139" className="flex items-center gap-1 text-amber-400 hover:underline font-semibold">
            <PhoneCall size={12} />
            <span>Emergency RPF: 139</span>
          </a>
        </div>
      </div>

      {/* Main Glass Navigation Bar */}
      <nav className={`px-4 lg:px-8 py-3.5 backdrop-blur-xl transition-colors duration-300 border-b ${
        isDarkMode 
          ? 'bg-slate-950/80 border-slate-800 text-slate-100' 
          : 'bg-white/90 border-slate-200 text-slate-900 shadow-md'
      }`}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          
          {/* Logo & Brand Identity */}
          <div 
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-railway-blue to-railway-cyan p-0.5 shadow-lg shadow-railway-blue/30 group-hover:scale-105 transition-transform">
                <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                  <Train className="w-5 h-5 text-railway-cyan group-hover:rotate-6 transition-transform" />
                </div>
              </div>
              <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-emerald-500 border-2 border-slate-900 animate-ping"></span>
              <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-emerald-500 border-2 border-slate-900"></span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-heading font-extrabold text-xl tracking-tight bg-gradient-to-r from-blue-400 via-cyan-300 to-indigo-300 bg-clip-text text-transparent">
                  SafeRail <span className="text-amber-400">AI</span>
                </span>
                <span className="px-1.5 py-0.5 text-[10px] font-mono font-bold bg-railway-blue/30 text-railway-cyan border border-railway-cyan/40 rounded">
                  v2.4
                </span>
              </div>
              <p className="text-[10px] text-slate-400 tracking-wide font-medium uppercase">
                Smart India Hackathon 2026 Project
              </p>
            </div>
          </div>

          {/* Desktop Nav Links */}
          <div className="hidden lg:flex items-center gap-6">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => handleNavClick(link.view, link.href)}
                className={`text-sm font-medium transition-colors hover:text-railway-cyan ${
                  currentView === 'home' ? 'text-slate-300' : 'text-slate-400'
                }`}
              >
                {link.label}
              </a>
            ))}

            {/* Dashboard Selector Dropdown / Shortcuts */}
            <div className="relative group">
              <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all">
                <LayoutDashboard size={14} className="text-railway-cyan" />
                <span>Live Portals</span>
              </button>

              <div className="absolute right-0 mt-2 w-56 p-2 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl opacity-0 group-hover:opacity-100 invisible group-hover:visible transition-all duration-200 z-50">
                <div className="text-[11px] font-semibold text-slate-400 px-2 py-1 uppercase tracking-wider">
                  Select User Dashboard
                </div>
                <button
                  onClick={() => handleNavClick('passenger')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs rounded-lg text-left transition-colors ${
                    currentView === 'passenger' ? 'bg-railway-blue text-white' : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <User size={14} className="text-cyan-400" />
                  <div>
                    <div className="font-semibold">Passenger Portal</div>
                    <div className="text-[10px] text-slate-400">Journey & SOS Trigger</div>
                  </div>
                </button>
                <button
                  onClick={() => handleNavClick('rpf')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs rounded-lg text-left transition-colors ${
                    currentView === 'rpf' ? 'bg-railway-blue text-white' : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <Shield size={14} className="text-amber-400" />
                  <div>
                    <div className="font-semibold">RPF Police Command</div>
                    <div className="text-[10px] text-slate-400">Incident Queue & Dispatch</div>
                  </div>
                </button>
                <button
                  onClick={() => handleNavClick('control_room')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs rounded-lg text-left transition-colors ${
                    currentView === 'control_room' ? 'bg-railway-blue text-white' : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <Radio size={14} className="text-emerald-400" />
                  <div>
                    <div className="font-semibold">National Control Room</div>
                    <div className="text-[10px] text-slate-400">National Map & CCTV Grid</div>
                  </div>
                </button>
                <button
                  onClick={() => handleNavClick('admin')}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs rounded-lg text-left transition-colors ${
                    currentView === 'admin' ? 'bg-railway-blue text-white' : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <Settings size={14} className="text-purple-400" />
                  <div>
                    <div className="font-semibold">Admin & Analytics</div>
                    <div className="text-[10px] text-slate-400">System Logs & Metrics</div>
                  </div>
                </button>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Dark / Light Toggle */}
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors border border-slate-700"
              title="Toggle Theme"
            >
              {isDarkMode ? <Sun size={17} className="text-amber-400" /> : <Moon size={17} className="text-indigo-400" />}
            </button>

            {/* Main Emergency SOS Button */}
            <button
              onClick={onOpenSos}
              className="relative group overflow-hidden rounded-xl px-4 py-2 bg-gradient-to-r from-red-600 to-rose-700 text-white font-bold text-xs tracking-wider shadow-lg shadow-red-600/40 hover:shadow-red-600/70 hover:scale-105 active:scale-95 transition-all flex items-center gap-2 border border-red-400/30"
            >
              <span className="w-2.5 h-2.5 rounded-full bg-white animate-ping"></span>
              <ShieldAlert size={16} className="text-white group-hover:rotate-12 transition-transform" />
              <span>EMERGENCY SOS</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              onClick={onOpenSos}
              className="px-3 py-1.5 bg-red-600 text-white font-bold text-xs rounded-lg flex items-center gap-1.5 shadow-md shadow-red-600/30"
            >
              <ShieldAlert size={14} />
              <span>SOS</span>
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-slate-800 text-slate-200 border border-slate-700"
            >
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden mt-4 p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-3 shadow-2xl animate-fadeIn">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => handleNavClick(link.view, link.href)}
                className="text-sm font-medium text-slate-300 hover:text-railway-cyan py-1.5"
              >
                {link.label}
              </a>
            ))}
            <hr className="border-slate-800" />
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Dashboards & Portals
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleNavClick('passenger')}
                className="p-2.5 rounded-xl bg-slate-800 text-left text-xs font-semibold text-slate-200 border border-slate-700 flex items-center gap-2"
              >
                <User size={14} className="text-cyan-400" />
                <span>Passenger</span>
              </button>
              <button
                onClick={() => handleNavClick('rpf')}
                className="p-2.5 rounded-xl bg-slate-800 text-left text-xs font-semibold text-slate-200 border border-slate-700 flex items-center gap-2"
              >
                <Shield size={14} className="text-amber-400" />
                <span>RPF Police</span>
              </button>
              <button
                onClick={() => handleNavClick('control_room')}
                className="p-2.5 rounded-xl bg-slate-800 text-left text-xs font-semibold text-slate-200 border border-slate-700 flex items-center gap-2"
              >
                <Radio size={14} className="text-emerald-400" />
                <span>Control Room</span>
              </button>
              <button
                onClick={() => handleNavClick('admin')}
                className="p-2.5 rounded-xl bg-slate-800 text-left text-xs font-semibold text-slate-200 border border-slate-700 flex items-center gap-2"
              >
                <Settings size={14} className="text-purple-400" />
                <span>Admin</span>
              </button>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};
