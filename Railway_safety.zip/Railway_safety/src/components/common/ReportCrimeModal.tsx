import React, { useState } from 'react';
import { FileText, X, Camera, Send, CheckCircle2 } from 'lucide-react';
import { mockJourney } from '../../data/mockData';

interface ReportCrimeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReportCrimeModal: React.FC<ReportCrimeModalProps> = ({ isOpen, onClose }) => {
  const [submitted, setSubmitted] = useState(false);
  const [crimeCategory, setCrimeCategory] = useState('Luggage Theft');
  const [details, setDetails] = useState('');
  const [anonymous, setAnonymous] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setDetails('');
      onClose();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg glass-card rounded-3xl border border-orange-500/50 bg-slate-950 p-6 sm:p-8 shadow-2xl">
        
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
        >
          <X size={18} />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 rounded-2xl bg-orange-500/20 text-orange-400 border border-orange-500/40">
            <FileText size={24} />
          </div>
          <div>
            <h3 className="text-xl font-bold font-heading text-white">File Railway Crime Incident</h3>
            <p className="text-xs text-slate-400">Direct transmission to Division Security Control</p>
          </div>
        </div>

        {submitted ? (
          <div className="py-8 text-center space-y-3">
            <CheckCircle2 size={44} className="mx-auto text-emerald-400 animate-bounce" />
            <div className="text-xl font-bold text-white">Report Registered Successfully</div>
            <div className="text-xs text-slate-300 font-mono">
              FIR Ref: RPF-2026-9042 &bull; Kanpur Division RPF Informed
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Crime / Incident Category</label>
              <select
                value={crimeCategory}
                onChange={(e) => setCrimeCategory(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white focus:border-orange-400 focus:outline-none"
              >
                <option>Luggage Theft / Pickpocketing</option>
                <option>Harassment / Verbal Abuse</option>
                <option>Unauthorized Passenger in Reserved Coach</option>
                <option>Vandalism / Property Damage</option>
                <option>Suspicious Package / Unattended Item</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-500">Train No:</span>
                <div className="text-white font-bold">{mockJourney.trainNo} ({mockJourney.trainName})</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-500">Coach / Seat:</span>
                <div className="text-amber-400 font-bold">{mockJourney.coach} - {mockJourney.seatNo}</div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Incident Description</label>
              <textarea
                rows={3}
                required
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="Describe the incident, suspect appearance, or missing items..."
                className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white focus:border-orange-400 focus:outline-none"
              ></textarea>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-300">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={anonymous}
                  onChange={(e) => setAnonymous(e.target.checked)}
                  className="rounded bg-slate-900 border-slate-800 text-orange-500 focus:ring-0"
                />
                <span>Submit as Anonymous Report</span>
              </label>

              <button type="button" className="flex items-center gap-1 text-slate-400 hover:text-cyan-400">
                <Camera size={14} />
                <span>Attach Photo</span>
              </button>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-400 hover:to-amber-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-orange-500/20"
            >
              <Send size={16} />
              <span>Submit Crime Incident Ticket</span>
            </button>
          </form>
        )}

      </div>
    </div>
  );
};
