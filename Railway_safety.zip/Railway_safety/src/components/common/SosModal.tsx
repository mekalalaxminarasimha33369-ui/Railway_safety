import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  X, 
  Volume2, 
  VolumeX, 
  MapPin, 
  CheckCircle2, 
  Radio, 
  Train, 
  AlertOctagon,
  PhoneCall,
  Activity
} from 'lucide-react';
import { mockJourney } from '../../data/mockData';

interface SosModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAlertTriggered?: (alertInfo: any) => void;
}

export const SosModal: React.FC<SosModalProps> = ({ isOpen, onClose, onAlertTriggered }) => {
  const [countdown, setCountdown] = useState<number>(3);
  const [isCounting, setIsCounting] = useState<boolean>(false);
  const [sosTriggered, setSosTriggered] = useState<boolean>(false);
  const [sirenActive, setSirenActive] = useState<boolean>(true);
  const [selectedEmergencyType, setSelectedEmergencyType] = useState<string>('Women Safety');
  const [audioStream, setAudioStream] = useState<boolean>(true);

  useEffect(() => {
    let timer: any;
    if (isCounting && countdown > 0) {
      timer = setInterval(() => {
        setCountdown((prev) => prev - 1);
      }, 1000);
    } else if (isCounting && countdown === 0) {
      setIsCounting(false);
      setSosTriggered(true);
      if (onAlertTriggered) {
        onAlertTriggered({
          id: `ALT-${Math.floor(1000 + Math.random() * 9000)}`,
          passengerName: 'Ananya Sharma',
          phone: '+91 98765 43210',
          trainNo: mockJourney.trainNo,
          trainName: mockJourney.trainName,
          coach: mockJourney.coach,
          seat: mockJourney.seatNo,
          location: 'KM 412 near Kanpur Central',
          type: selectedEmergencyType,
          status: 'CRITICAL',
          timestamp: 'Just Now',
          aiDetected: false
        });
      }
    }
    return () => clearInterval(timer);
  }, [isCounting, countdown]);

  if (!isOpen) return null;

  const startSosCountdown = () => {
    setCountdown(3);
    setIsCounting(true);
    setSosTriggered(false);
  };

  const cancelSos = () => {
    setIsCounting(false);
    setCountdown(3);
    setSosTriggered(false);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl animate-fadeIn">
      
      <div className="relative w-full max-w-xl glass-card rounded-3xl border border-rose-500/60 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 p-6 sm:p-8 shadow-2xl shadow-rose-900/50">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
        >
          <X size={20} />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 rounded-2xl bg-rose-600/20 text-rose-400 border border-rose-500/40">
            <ShieldAlert size={28} className="animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping"></span>
              <h2 className="text-xl font-bold font-heading text-white">HIGH PRIORITY SOS TRIGGER</h2>
            </div>
            <p className="text-xs text-rose-300/80 font-mono">Indian Railways Emergency Dispatch System</p>
          </div>
        </div>

        {/* Emergency Type Selector */}
        {!isCounting && !sosTriggered && (
          <div className="space-y-6">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2 uppercase tracking-wider">
                Select Emergency Category
              </label>
              <div className="grid grid-cols-2 gap-2 sm:gap-3">
                {[
                  { name: 'Women Safety', desc: 'Harassment / Threat' },
                  { name: 'Medical Emergency', desc: 'Cardiac / Critical Health' },
                  { name: 'Theft / Robbery', desc: 'Property / Stolen Luggage' },
                  { name: 'Child Safety', desc: 'Unattended / Separated' },
                ].map((item) => (
                  <button
                    key={item.name}
                    onClick={() => setSelectedEmergencyType(item.name)}
                    className={`p-3 rounded-2xl text-left border transition-all ${
                      selectedEmergencyType === item.name
                        ? 'bg-rose-950/80 border-rose-500 text-rose-200 shadow-md'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="font-bold text-xs">{item.name}</div>
                    <div className="text-[10px] opacity-70">{item.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Active Telemetry Summary Card */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs space-y-2 font-mono">
              <div className="flex justify-between text-slate-400">
                <span>Train Details:</span>
                <span className="text-white font-bold">{mockJourney.trainNo} - {mockJourney.trainName}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Current Carriage:</span>
                <span className="text-amber-400 font-bold">Coach {mockJourney.coach}, Seat {mockJourney.seatNo}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Live Geo-Location:</span>
                <span className="text-cyan-400 font-bold">KM 412 (Kanpur Central)</span>
              </div>
            </div>

            {/* Trigger Button */}
            <button
              onClick={startSosCountdown}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:from-rose-500 hover:to-red-500 text-white font-extrabold text-sm tracking-wider shadow-xl shadow-rose-600/40 hover:scale-102 active:scale-98 transition-all flex items-center justify-center gap-2 border border-rose-400/40"
            >
              <AlertOctagon size={20} className="animate-spin" />
              <span>PRESS TO START 3-SEC EMERGENCY COUNTDOWN</span>
            </button>
          </div>
        )}

        {/* Countdown Active State */}
        {isCounting && (
          <div className="py-8 text-center space-y-6 animate-pulse">
            <div className="w-28 h-28 mx-auto rounded-full bg-rose-600/20 border-4 border-rose-500 flex items-center justify-center text-5xl font-black font-mono text-rose-400 shadow-[0_0_30px_#d32f2f]">
              {countdown}
            </div>
            <div>
              <div className="text-lg font-bold text-white uppercase tracking-wide">
                Broadcasting Emergency Payload in {countdown} Seconds...
              </div>
              <p className="text-xs text-slate-400 mt-1">
                RPF Command, Train Superintendent, and Emergency Contacts will be alerted.
              </p>
            </div>
            <button
              onClick={cancelSos}
              className="px-8 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700"
            >
              CANCEL EMERGENCY SOS
            </button>
          </div>
        )}

        {/* SOS Triggered Success Dispatch State */}
        {sosTriggered && (
          <div className="py-6 space-y-6">
            <div className="p-4 rounded-2xl bg-emerald-500/20 border border-emerald-500/50 text-center text-emerald-300 space-y-2">
              <CheckCircle2 size={40} className="mx-auto text-emerald-400 animate-bounce" />
              <div className="text-xl font-bold font-heading text-white">SOS DISPATCH BROADCAST ACTIVE</div>
              <div className="text-xs font-mono">Alert ID: ALT-9042 &bull; Status: RPF Dispatched</div>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-300">
                  <Radio size={14} className="text-cyan-400 animate-pulse" />
                  Live GPS Coordinates Stream
                </span>
                <span className="text-emerald-400 font-bold">TRANSMITTING</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-300">
                  <Volume2 size={14} className="text-amber-400 animate-pulse" />
                  Encrypted Audio Corridor Stream
                </span>
                <span className="text-emerald-400 font-bold">RECORDING (10s)</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-300">
                  <Train size={14} className="text-indigo-400" />
                  Onboard Escort RPF Squad #4
                </span>
                <span className="text-amber-400 font-bold">EN ROUTE TO B4-32 (&lt;2 MINS)</span>
              </div>
            </div>

            <div className="flex gap-3">
              <a
                href="tel:139"
                className="flex-1 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs text-center flex items-center justify-center gap-2 shadow-lg"
              >
                <PhoneCall size={16} />
                <span>Call RPF Control 139 Direct</span>
              </a>
              <button
                onClick={cancelSos}
                className="px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
              >
                Dismiss Window
              </button>
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
