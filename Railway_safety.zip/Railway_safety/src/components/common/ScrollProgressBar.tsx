import React, { useEffect, useState } from 'react';

export const ScrollProgressBar: React.FC = () => {
  const [scrollPercentage, setScrollPercentage] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const windowHeight = window.innerHeight;
      const documentHeight = document.documentElement.scrollHeight - windowHeight;
      const scrolled = window.scrollY;
      if (documentHeight > 0) {
        setScrollPercentage((scrolled / documentHeight) * 100);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="fixed top-0 left-0 w-full h-1 z-[100] bg-slate-900">
      <div
        className="h-full bg-gradient-to-r from-railway-blue via-cyan-400 via-amber-400 to-emerald-400 transition-all duration-150 shadow-[0_0_10px_#00e5ff]"
        style={{ width: `${scrollPercentage}%` }}
      ></div>
    </div>
  );
};
