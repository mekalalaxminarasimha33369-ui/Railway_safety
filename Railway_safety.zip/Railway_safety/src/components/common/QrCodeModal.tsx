import React from 'react';
import { QrCode, X, ShieldCheck, Download, Train, User } from 'lucide-react';
import { mockJourney } from '../../data/mockData';

interface QrCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const QrCodeModal: React.FC<QrCodeModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-md glass-card rounded-3xl border border-teal-500/50 bg-slate-950 p-6 sm:p-8 shadow-2xl">
        
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
        >
          <X size={18} />
        </button>

        <div className="text-center mb-6">
          <span className="px-3 py-1 rounded-full bg-teal-500/20 text-teal-400 text-xs font-mono font-bold">
            DIGITAL EMERGENCY IDENTITY PASS
          </span>
          <h3 className="text-xl font-bold font-heading text-white mt-2">
            SafeRail Security QR Pass
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Tamper-proof encrypted pass for RPF squad inspection.
          </p>
        </div>

        {/* QR Code Container */}
        <div className="p-6 rounded-3xl bg-white text-slate-950 flex flex-col items-center justify-center shadow-inner mb-6">
          {/* Simulated QR Code SVG Grid */}
          <div className="w-44 h-44 bg-slate-950 p-3 rounded-2xl flex items-center justify-center">
            <QrCode size={140} className="text-teal-400" />
          </div>
          <div className="mt-3 font-mono text-[10px] text-slate-600 font-bold tracking-widest">
            HASH: 8F92-4B09-12423-B432
          </div>
        </div>

        {/* Passenger Data Card */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-xs font-mono space-y-2 mb-6">
          <div className="flex justify-between text-slate-400">
            <span>Passenger Name:</span>
            <span className="text-white font-bold">Ananya Sharma</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>PNR Number:</span>
            <span className="text-teal-400 font-bold">{mockJourney.pnr}</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>Train & Coach:</span>
            <span className="text-amber-400 font-bold">12423 &bull; B4 - 32</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>Emergency Contact:</span>
            <span className="text-white font-bold">+91 98765 43210 (Father)</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>Blood Group:</span>
            <span className="text-rose-400 font-bold">O+ Positive</span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-3 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-teal-500/20"
        >
          <Download size={16} />
          <span>Save Digital Security QR Pass</span>
        </button>

      </div>
    </div>
  );
};
