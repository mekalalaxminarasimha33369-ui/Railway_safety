import React, { useState } from 'react';
import { 
  Bot, 
  X, 
  Send, 
  Sparkles, 
  ShieldCheck, 
  Globe, 
  Languages,
  User,
  Activity
} from 'lucide-react';
import { Language } from '../../types';

interface AiChatbotModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSos: () => void;
}

export const AiChatbotModal: React.FC<AiChatbotModalProps> = ({ isOpen, onClose, onOpenSos }) => {
  const [selectedLang, setSelectedLang] = useState<Language>('EN');
  const [inputMsg, setInputMsg] = useState<string>('');
  const [chatLog, setChatLog] = useState<Array<{ sender: 'bot' | 'user'; text: string; time: string }>>([
    {
      sender: 'bot',
      text: 'Namaste! I am RailRakshak AI, your 24x7 intelligent railway passenger safety assistant. How can I protect your journey today?',
      time: '10:52 AM'
    }
  ]);
  const [isTyping, setIsTyping] = useState<boolean>(false);

  if (!isOpen) return null;

  const quickPrompts = [
    "How do I activate SOS voice trigger?",
    "What to do if my luggage is stolen?",
    "Report harassment in coach B4",
    "Where is the nearest medical bay?"
  ];

  const handleSendMessage = (textToSend?: string) => {
    const msg = textToSend || inputMsg;
    if (!msg.trim()) return;

    const userMessageObj = {
      sender: 'user' as const,
      text: msg,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatLog((prev) => [...prev, userMessageObj]);
    if (!textToSend) setInputMsg('');
    setIsTyping(true);

    setTimeout(() => {
      let reply = "SafeRail AI has logged your request. For immediate physical emergency dispatch, please press the Red Emergency SOS button in the top navigation bar.";
      
      const lower = msg.toLowerCase();
      if (lower.includes('sos') || lower.includes('voice')) {
        reply = "To trigger Voice SOS, say out loud: 'Help Me SafeRail' or press the Emergency SOS button. Your carriage location (Train 12423, Coach B4, Seat 32) will be transmitted instantly to onboard RPF.";
      } else if (lower.includes('stolen') || lower.includes('theft') || lower.includes('luggage')) {
        reply = "I can immediately register a theft report. Would you like to transmit your PNR details to Kanpur Central RPF Control Room?";
      } else if (lower.includes('medical') || lower.includes('doctor')) {
        reply = "Emergency medical alert queued! The RPF medical squad at Kanpur Central has been notified to meet Coach B4 upon platform arrival.";
      } else if (lower.includes('harass') || lower.includes('women')) {
        reply = "Women Security Protocol activated. Lady RPF squad on board Train 12423 has been alerted to patrol Coach B4 immediately.";
      }

      setChatLog((prev) => [
        ...prev,
        {
          sender: 'bot',
          text: reply,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
      setIsTyping(false);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      
      <div className="relative w-full max-w-lg glass-card rounded-3xl border border-cyan-500/50 bg-slate-950 flex flex-col h-[600px] shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="bg-slate-900 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40">
              <Bot size={22} className="animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold font-heading text-white">RailRakshak AI Assistant</h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/20 text-cyan-300">v4.2</span>
              </div>
              <p className="text-[10px] text-slate-400">Multilingual Railway Safety GPT</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Language Selector */}
            <select
              value={selectedLang}
              onChange={(e) => setSelectedLang(e.target.value as Language)}
              className="px-2 py-1 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-700 focus:outline-none"
            >
              <option value="EN">English</option>
              <option value="HI">हिंदी (Hindi)</option>
              <option value="TA">தமிழ் (Tamil)</option>
              <option value="TE">తెలుగు (Telugu)</option>
              <option value="BN">বাংলা (Bengali)</option>
            </select>

            <button onClick={onClose} className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Chat History Box */}
        <div className="flex-1 p-6 overflow-y-auto space-y-4 font-sans text-xs">
          {chatLog.map((chat, idx) => (
            <div
              key={idx}
              className={`flex items-start gap-2.5 ${chat.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {chat.sender === 'bot' && (
                <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 flex items-center justify-center shrink-0 mt-1">
                  <Bot size={14} />
                </div>
              )}

              <div
                className={`max-w-[80%] p-3.5 rounded-2xl ${
                  chat.sender === 'user'
                    ? 'bg-railway-blue text-white rounded-tr-none'
                    : 'bg-slate-900 text-slate-200 border border-slate-800 rounded-tl-none'
                }`}
              >
                <p className="leading-relaxed">{chat.text}</p>
                <div className="mt-1 text-[9px] opacity-60 text-right">{chat.time}</div>
              </div>

              {chat.sender === 'user' && (
                <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center shrink-0 mt-1">
                  <User size={14} />
                </div>
              )}
            </div>
          ))}

          {isTyping && (
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-mono">
              <Activity size={14} className="animate-spin" />
              <span>RailRakshak AI is formulating response...</span>
            </div>
          )}
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-4 py-2 bg-slate-900/60 border-t border-slate-800/80 flex flex-wrap gap-1.5">
          {quickPrompts.map((prompt, i) => (
            <button
              key={i}
              onClick={() => handleSendMessage(prompt)}
              className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-medium border border-slate-700 transition-colors"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Input Form Bar */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center gap-2">
          <input
            type="text"
            value={inputMsg}
            onChange={(e) => setInputMsg(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Ask AI safety assistant or report an issue..."
            className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:border-cyan-400 focus:outline-none"
          />
          <button
            onClick={() => handleSendMessage()}
            className="p-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold shadow-md shadow-cyan-500/20"
          >
            <Send size={16} />
          </button>
        </div>

      </div>

    </div>
  );
};
