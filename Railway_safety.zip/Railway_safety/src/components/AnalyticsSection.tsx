import React, { useState } from 'react';
import { 
  TrendingUp, 
  BarChart3, 
  Clock, 
  ShieldCheck, 
  HeartPulse, 
  AlertTriangle, 
  PieChart, 
  Map
} from 'lucide-react';

export const AnalyticsSection: React.FC = () => {
  const [selectedMetric, setSelectedMetric] = useState<'crime' | 'response' | 'women' | 'medical'>('crime');

  return (
    <section id="analytics" className="py-20 bg-slate-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="px-3.5 py-1.5 rounded-full bg-blue-500/10 text-cyan-400 border border-cyan-500/30 text-xs font-semibold uppercase tracking-wider">
            Data-Driven Security Intelligence
          </span>
          <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight">
            Safety <span className="text-cyan-400">Analytics & Insights</span>
          </h2>
          <p className="mt-4 text-base text-slate-400">
            Real-time telemetry and historical crime trend analysis empowering Indian Railways security commanders.
          </p>
        </div>

        {/* Metric Selector Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          <div className="p-1 rounded-2xl bg-slate-950 border border-slate-800 flex flex-wrap gap-1">
            <button
              onClick={() => setSelectedMetric('crime')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                selectedMetric === 'crime'
                  ? 'bg-railway-blue text-white shadow-lg'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <BarChart3 size={14} />
              <span>Monthly Crimes & Theft</span>
            </button>

            <button
              onClick={() => setSelectedMetric('response')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                selectedMetric === 'response'
                  ? 'bg-railway-blue text-white shadow-lg'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Clock size={14} />
              <span>RPF Response Time</span>
            </button>

            <button
              onClick={() => setSelectedMetric('women')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                selectedMetric === 'women'
                  ? 'bg-railway-blue text-white shadow-lg'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ShieldCheck size={14} />
              <span>Women Safety Metrics</span>
            </button>

            <button
              onClick={() => setSelectedMetric('medical')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                selectedMetric === 'medical'
                  ? 'bg-railway-blue text-white shadow-lg'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <HeartPulse size={14} />
              <span>Medical Emergency Cases</span>
            </button>
          </div>
        </div>

        {/* Dynamic Analytics Visualizer Card */}
        <div className="glass-card p-8 rounded-3xl border border-slate-800 bg-slate-950 shadow-2xl">
          
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-8 border-b border-slate-800 pb-6">
            <div>
              <h3 className="text-xl font-bold font-heading text-white">
                {selectedMetric === 'crime' && 'Monthly Reported Incidents & AI Prevention Rate'}
                {selectedMetric === 'response' && 'Average RPF Tactical Response Time (Minutes)'}
                {selectedMetric === 'women' && 'Women Commuter Protection Index & Escort Coverage'}
                {selectedMetric === 'medical' && 'Medical Emergency Calls Handled Onboard'}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Data refreshed live from 18 Railway Zones &bull; DPDP Audit Compliant
              </p>
            </div>
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs font-mono font-bold">
                -42% Crime Drop YoY
              </span>
            </div>
          </div>

          {/* SVG Bar / Line Chart Simulation */}
          <div className="h-64 w-full flex items-end justify-between gap-2 sm:gap-4 px-2 sm:px-6 pt-6 border-b border-slate-800">
            {[
              { month: 'Jan', val: 78, prev: 120 },
              { month: 'Feb', val: 64, prev: 110 },
              { month: 'Mar', val: 52, prev: 105 },
              { month: 'Apr', val: 45, prev: 98 },
              { month: 'May', val: 38, prev: 92 },
              { month: 'Jun', val: 32, prev: 88 },
              { month: 'Jul', val: 24, prev: 80 },
              { month: 'Aug', val: 18, prev: 75 }
            ].map((item, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center gap-2 group h-full justify-end">
                <div className="text-[10px] font-mono text-cyan-400 font-bold opacity-0 group-hover:opacity-100 transition-opacity">
                  {item.val}
                </div>
                <div className="w-full flex items-end justify-center gap-1 h-full">
                  {/* Previous year bar */}
                  <div 
                    style={{ height: `${item.prev}%` }} 
                    className="w-1/2 bg-slate-800 rounded-t group-hover:bg-slate-700 transition-colors" 
                    title={`2025: ${item.prev}`}
                  ></div>
                  {/* SafeRail AI bar */}
                  <div 
                    style={{ height: `${item.val}%` }} 
                    className="w-1/2 bg-gradient-to-t from-railway-blue to-cyan-400 rounded-t shadow-lg shadow-cyan-500/30 group-hover:scale-105 transition-transform"
                    title={`2026 SafeRail AI: ${item.val}`}
                  ></div>
                </div>
                <span className="text-[11px] font-mono text-slate-400 group-hover:text-white transition-colors">
                  {item.month}
                </span>
              </div>
            ))}
          </div>

          {/* Chart Legend */}
          <div className="mt-6 flex flex-wrap items-center justify-between text-xs text-slate-400 font-mono">
            <div className="flex items-center gap-6">
              <span className="flex items-center gap-2">
                <span className="w-3 h-3 rounded bg-slate-800"></span>
                <span>Before SafeRail AI Implementation</span>
              </span>
              <span className="flex items-center gap-2">
                <span className="w-3 h-3 rounded bg-gradient-to-r from-railway-blue to-cyan-400"></span>
                <span>With SafeRail AI Deployment</span>
              </span>
            </div>
            <span>Average Dispatch Latency: <strong className="text-emerald-400">2m 14s</strong></span>
          </div>

        </div>

      </div>
    </section>
  );
};
