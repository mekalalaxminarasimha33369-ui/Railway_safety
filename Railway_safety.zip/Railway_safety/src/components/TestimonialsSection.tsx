import React from 'react';
import { Star, Quote, Shield, UserCheck, HeartPulse } from 'lucide-react';
import { mockTestimonials } from '../data/mockData';

export const TestimonialsSection: React.FC = () => {
  return (
    <section className="py-20 bg-slate-950 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="px-3.5 py-1.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30 text-xs font-semibold uppercase tracking-wider">
            Verified Stakeholder Endorsements
          </span>
          <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight">
            Trusted by <span className="text-amber-400">Rail Command & Commuters</span>
          </h2>
          <p className="mt-4 text-base text-slate-400">
            Hear from Railway Protection Force commanders, frequent passengers, and medical officers experiencing SafeRail AI's real-world impact.
          </p>
        </div>

        {/* Testimonials Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {mockTestimonials.map((item) => (
            <div
              key={item.id}
              className="glass-card p-8 rounded-3xl border border-slate-800 hover:border-amber-500/50 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 flex flex-col justify-between"
            >
              <div>
                {/* Rating Stars & Quote Icon */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-1 text-amber-400">
                    {Array.from({ length: item.rating }).map((_, i) => (
                      <Star key={i} size={16} className="fill-amber-400" />
                    ))}
                  </div>
                  <Quote size={24} className="text-slate-700" />
                </div>

                <p className="text-xs sm:text-sm text-slate-300 italic leading-relaxed mb-6">
                  "{item.quote}"
                </p>
              </div>

              {/* User Avatar & Info */}
              <div className="pt-6 border-t border-slate-800 flex items-center gap-4">
                <img
                  src={item.avatar}
                  alt={item.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-amber-400/40"
                />
                <div>
                  <h3 className="text-sm font-bold text-white">{item.name}</h3>
                  <p className="text-xs text-amber-400 font-medium">{item.role}</p>
                  <p className="text-[10px] text-slate-400 font-mono">{item.organization}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
