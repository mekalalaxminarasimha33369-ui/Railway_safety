import React, { useState } from 'react';
import { 
  Eye, 
  AlertTriangle, 
  MapPin, 
  ScanFace, 
  Mic, 
  HeartPulse, 
  Search, 
  ShieldCheck, 
  FileText, 
  ShieldAlert, 
  Activity, 
  WifiOff, 
  QrCode, 
  Bot, 
  BrainCircuit, 
  Navigation, 
  Bell, 
  Languages, 
  Flame, 
  CheckCircle,
  Filter
} from 'lucide-react';
import { mockFeatures } from '../data/mockData';
import { FeatureItem } from '../types';

export const FeaturesSection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Passenger', 'RPF', 'AI Surveillance', 'Safety'];

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Eye': return <Eye size={24} className="text-cyan-400" />;
      case 'AlertTriangle': return <AlertTriangle size={24} className="text-rose-400" />;
      case 'MapPin': return <MapPin size={24} className="text-emerald-400" />;
      case 'ScanFace': return <ScanFace size={24} className="text-purple-400" />;
      case 'Mic': return <Mic size={24} className="text-amber-400" />;
      case 'HeartPulse': return <HeartPulse size={24} className="text-pink-400" />;
      case 'Search': return <Search size={24} className="text-blue-400" />;
      case 'ShieldCheck': return <ShieldCheck size={24} className="text-pink-400" />;
      case 'FileText': return <FileText size={24} className="text-orange-400" />;
      case 'ShieldAlert': return <ShieldAlert size={24} className="text-indigo-400" />;
      case 'Activity': return <Activity size={24} className="text-cyan-400" />;
      case 'WifiOff': return <WifiOff size={24} className="text-slate-400" />;
      case 'QrCode': return <QrCode size={24} className="text-teal-400" />;
      case 'Bot': return <Bot size={24} className="text-blue-400" />;
      case 'BrainCircuit': return <BrainCircuit size={24} className="text-purple-400" />;
      case 'Navigation': return <Navigation size={24} className="text-emerald-400" />;
      default: return <ShieldCheck size={24} className="text-cyan-400" />;
    }
  };

  const filteredFeatures = selectedCategory === 'All' 
    ? mockFeatures 
    : mockFeatures.filter(f => f.category === selectedCategory);

  return (
    <section id="features" className="py-20 bg-slate-950 relative">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="px-3.5 py-1.5 rounded-full bg-cyan-500/10 text-railway-cyan border border-cyan-500/30 text-xs font-semibold uppercase tracking-wider">
            Comprehensive Enterprise Safety Suite
          </span>
          <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight">
            Next-Gen Safety <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">Capabilities</span>
          </h2>
          <p className="mt-4 text-base text-slate-400">
            Powered by modern AI algorithms, IoT sensors, and high-speed telemetry to protect millions of railway travelers every day.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          <div className="p-1 rounded-2xl bg-slate-900 border border-slate-800 flex flex-wrap gap-1">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                  selectedCategory === cat
                    ? 'bg-railway-blue text-white shadow-lg shadow-railway-blue/40'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredFeatures.map((feature) => (
            <div
              key={feature.id}
              className="glass-card group relative p-6 rounded-3xl border border-slate-800 hover:border-cyan-500/50 bg-gradient-to-b from-slate-900/90 via-slate-900/60 to-slate-950 flex flex-col justify-between transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl hover:shadow-cyan-500/10"
            >
              {/* Top Row: Icon & Badge */}
              <div>
                <div className="flex items-center justify-between mb-5">
                  <div className={`p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/60 shadow-inner group-hover:scale-110 transition-transform`}>
                    {getIcon(feature.iconName)}
                  </div>
                  {feature.badge && (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-railway-cyan/10 text-railway-cyan border border-railway-cyan/30">
                      {feature.badge}
                    </span>
                  )}
                </div>

                {/* Title */}
                <h3 className="text-lg font-bold font-heading text-white group-hover:text-cyan-300 transition-colors mb-2">
                  {feature.title}
                </h3>

                {/* Category tag */}
                <span className="inline-block text-[11px] font-mono text-slate-400 mb-3">
                  Category: <span className="text-slate-300">{feature.category}</span>
                </span>

                {/* Description */}
                <p className="text-xs text-slate-400 leading-relaxed">
                  {feature.description}
                </p>
              </div>

              {/* Bottom Subtle Indicator */}
              <div className="mt-6 pt-4 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400 group-hover:text-cyan-400 transition-colors">
                <span className="font-semibold">Active & Live Grid</span>
                <CheckCircle size={14} className="text-emerald-400" />
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
