import React from 'react';
import { Train, ShieldCheck, Heart, ExternalLink } from 'lucide-react';
import { AppView } from '../types';

interface FooterProps {
  onSelectView: (view: AppView) => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectView }) => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          
          {/* Brand Col */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-railway-blue p-0.5 flex items-center justify-center text-cyan-400 font-bold">
                <Train size={20} />
              </div>
              <span className="font-heading font-extrabold text-xl text-white">
                SafeRail <span className="text-amber-400">AI</span>
              </span>
            </div>
            <p className="text-xs leading-relaxed text-slate-400">
              AI-Powered Smart Railway Passenger Safety System developed for Indian Railways as part of the Smart India Hackathon (SIH) 2026.
            </p>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-[10px] text-amber-400 font-mono font-bold">
              <span>SIH 2026 Grand Finalist</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4 font-mono">
              Quick Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#hero" className="hover:text-cyan-400 transition-colors">Home & Hero</a></li>
              <li><a href="#about" className="hover:text-cyan-400 transition-colors">About Solution</a></li>
              <li><a href="#features" className="hover:text-cyan-400 transition-colors">Safety Features</a></li>
              <li><a href="#how-it-works" className="hover:text-cyan-400 transition-colors">How It Works</a></li>
              <li><a href="#ai-modules" className="hover:text-cyan-400 transition-colors">AI Services</a></li>
              <li><a href="#architecture" className="hover:text-cyan-400 transition-colors">System Architecture</a></li>
            </ul>
          </div>

          {/* Operational Portals */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4 font-mono">
              Live Portals & Dashboards
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onSelectView('passenger')} className="hover:text-cyan-400 transition-colors text-left">
                  Passenger Safety App
                </button>
              </li>
              <li>
                <button onClick={() => onSelectView('rpf')} className="hover:text-amber-400 transition-colors text-left">
                  RPF Tactical Command
                </button>
              </li>
              <li>
                <button onClick={() => onSelectView('control_room')} className="hover:text-emerald-400 transition-colors text-left">
                  National Control Room
                </button>
              </li>
              <li>
                <button onClick={() => onSelectView('admin')} className="hover:text-purple-400 transition-colors text-left">
                  Admin Security Analytics
                </button>
              </li>
            </ul>
          </div>

          {/* Governance & Compliance */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4 font-mono">
              Governance & Policies
            </h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#" className="hover:text-cyan-400 transition-colors">DPDP Act 2023 Compliance</a></li>
              <li><a href="#" className="hover:text-cyan-400 transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-cyan-400 transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-cyan-400 transition-colors">RPF Standard Operating Manual</a></li>
              <li><a href="#" className="hover:text-cyan-400 transition-colors flex items-center gap-1">
                <span>Indian Railways Official</span>
                <ExternalLink size={10} />
              </a></li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <div>
            &copy; 2026 SafeRail AI &bull; Smart India Hackathon (SIH) &bull; Ministry of Railways, Govt of India.
          </div>
          <div className="flex items-center gap-1 text-slate-400">
            <span>Engineered for</span>
            <span className="text-amber-400 font-bold">Indian Railways</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
