import React from 'react';
import { 
  Code2, 
  Server, 
  Cpu, 
  Database, 
  Layers, 
  Radio, 
  Zap, 
  ShieldCheck
} from 'lucide-react';

export const TechStackSection: React.FC = () => {
  const frontendStack = [
    { name: "React.js", desc: "Component Architecture", badge: "v18.3" },
    { name: "Tailwind CSS", desc: "Glassmorphism & Theme Design", badge: "v3.4" },
    { name: "TypeScript", desc: "Strict End-to-End Typing", badge: "v5.7" },
    { name: "Framer Motion", desc: "60fps Smooth Micro-Animations", badge: "UI/UX" },
    { name: "Chart.js / Recharts", desc: "Real-time Telemetry Graphs", badge: "Data" },
    { name: "Leaflet Maps API", desc: "Geo-Fenced Tactical Mapping", badge: "GIS" }
  ];

  const backendStack = [
    { name: "Node.js & Express", desc: "High-Throughput Microservices", badge: "Runtime" },
    { name: "MongoDB Cluster", desc: "Geo-Spatial Incident Indexing", badge: "Database" },
    { name: "Socket.io Engine", desc: "Sub-10ms Live SOS WebSockets", badge: "Realtime" },
    { name: "JWT & DPDP Security", desc: "Encrypted Auth & Privacy", badge: "Auth" },
    { name: "Firebase FCM", desc: "Push Alert Broadcast Engine", badge: "Mobile" },
    { name: "Cloudinary Media Hub", desc: "CCTV Evidence Storage", badge: "Cloud" }
  ];

  const aiStack = [
    { name: "YOLOv8 Vision", desc: "Object & Threat Detection", badge: "99.2%" },
    { name: "OpenCV Library", desc: "Frame Extraction & Filtering", badge: "Computer Vision" },
    { name: "TensorFlow RT", desc: "Edge Acceleration Engine", badge: "CUDA" },
    { name: "OpenAI GPT-4o API", desc: "RailRakshak Multilingual Bot", badge: "NLP" }
  ];

  return (
    <section id="tech-stack" className="py-20 bg-slate-950 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="px-3.5 py-1.5 rounded-full bg-blue-500/10 text-cyan-400 border border-cyan-500/30 text-xs font-semibold uppercase tracking-wider">
            Industrial Grade Infrastructure
          </span>
          <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight">
            Enterprise <span className="bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">Tech Stack</span>
          </h2>
          <p className="mt-4 text-base text-slate-400">
            Engineered for high availability, fault-tolerance, and ultra-low latency across urban hubs and remote rail tracks.
          </p>
        </div>

        {/* 3 Main Architecture Columns */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Frontend Card */}
          <div className="glass-card p-6 rounded-3xl border border-cyan-900/40 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950">
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-800">
              <div className="p-3 rounded-2xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                <Code2 size={24} />
              </div>
              <div>
                <h3 className="text-xl font-bold font-heading text-white">Frontend Platform</h3>
                <p className="text-xs text-cyan-300 font-mono">Modern Responsive UI Framework</p>
              </div>
            </div>

            <div className="space-y-3">
              {frontendStack.map((tech, i) => (
                <div key={i} className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-sm font-bold text-slate-200">{tech.name}</div>
                    <div className="text-xs text-slate-400">{tech.desc}</div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-slate-800 text-cyan-300 border border-cyan-500/30">
                    {tech.badge}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Backend Card */}
          <div className="glass-card p-6 rounded-3xl border border-blue-900/40 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950">
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-800">
              <div className="p-3 rounded-2xl bg-blue-500/10 text-blue-400 border border-blue-500/30">
                <Server size={24} />
              </div>
              <div>
                <h3 className="text-xl font-bold font-heading text-white">Backend Microservices</h3>
                <p className="text-xs text-blue-300 font-mono">Real-time Telemetry & SOS Mesh</p>
              </div>
            </div>

            <div className="space-y-3">
              {backendStack.map((tech, i) => (
                <div key={i} className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-sm font-bold text-slate-200">{tech.name}</div>
                    <div className="text-xs text-slate-400">{tech.desc}</div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-slate-800 text-blue-300 border border-blue-500/30">
                    {tech.badge}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* AI & Edge Vision Card */}
          <div className="glass-card p-6 rounded-3xl border border-purple-900/40 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950">
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-800">
              <div className="p-3 rounded-2xl bg-purple-500/10 text-purple-400 border border-purple-500/30">
                <Cpu size={24} />
              </div>
              <div>
                <h3 className="text-xl font-bold font-heading text-white">AI Engine & Computer Vision</h3>
                <p className="text-xs text-purple-300 font-mono">YOLOv8 + CUDA Acceleration</p>
              </div>
            </div>

            <div className="space-y-3">
              {aiStack.map((tech, i) => (
                <div key={i} className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-sm font-bold text-slate-200">{tech.name}</div>
                    <div className="text-xs text-slate-400">{tech.desc}</div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-slate-800 text-purple-300 border border-purple-500/30">
                    {tech.badge}
                  </span>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
