import React from 'react';
import { 
  ShieldCheck, 
  Sparkles, 
  Activity, 
  Radio, 
  Zap, 
  ArrowRight, 
  Play, 
  Train, 
  MapPin, 
  Bell, 
  Lock, 
  Cpu
} from 'lucide-react';
import { AppView } from '../types';

interface HeroProps {
  onOpenSos: () => void;
  onSelectView: (view: AppView) => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenSos, onSelectView }) => {
  return (
    <section id="hero" className="relative min-h-[92vh] flex flex-col justify-center items-center overflow-hidden pt-6 pb-16 bg-slate-950">
      
      {/* Background Animated Elements */}
      <div className="absolute inset-0 bg-cyber-grid bg-grid-pattern opacity-15 pointer-events-none"></div>

      {/* Radiant Gradient Blurs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-tr from-railway-blue/30 via-cyan-500/20 to-indigo-600/30 rounded-full blur-[130px] pointer-events-none"></div>
      <div className="absolute bottom-10 right-10 w-[350px] h-[350px] bg-amber-500/15 rounded-full blur-[100px] pointer-events-none"></div>

      {/* Floating AI Particles & Icons */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-20 left-[12%] animate-float" style={{ animationDelay: '0s' }}>
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-cyan-500/30 backdrop-blur-md shadow-xl text-cyan-400 flex items-center gap-2 text-xs font-mono">
            <Cpu size={16} />
            <span>YOLOv8 Vision Processing</span>
          </div>
        </div>

        <div className="absolute top-36 right-[12%] animate-float" style={{ animationDelay: '1.5s' }}>
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-emerald-500/30 backdrop-blur-md shadow-xl text-emerald-400 flex items-center gap-2 text-xs font-mono">
            <ShieldCheck size={16} />
            <span>RPF Live Mesh Active</span>
          </div>
        </div>

        <div className="absolute bottom-40 left-[8%] animate-float" style={{ animationDelay: '2.5s' }}>
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-amber-500/30 backdrop-blur-md shadow-xl text-amber-400 flex items-center gap-2 text-xs font-mono">
            <MapPin size={16} />
            <span>GPS Geo-Fencing: 750+ Hubs</span>
          </div>
        </div>

        <div className="absolute bottom-32 right-[8%] animate-float" style={{ animationDelay: '3.5s' }}>
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-rose-500/30 backdrop-blur-md shadow-xl text-rose-400 flex items-center gap-2 text-xs font-mono">
            <Bell size={16} />
            <span>Sub-3 Min Emergency Response</span>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center">
        
        {/* Status Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900/90 border border-railway-cyan/40 text-railway-cyan text-xs font-semibold tracking-wide uppercase mb-6 shadow-lg shadow-cyan-500/10 backdrop-blur-md">
          <Sparkles size={14} className="animate-spin text-amber-400" />
          <span>Smart India Hackathon 2026 Innovation</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
          <span className="text-slate-400 hidden sm:inline">&bull; Indian Railways Edition</span>
        </div>

        {/* Main Heading */}
        <h1 className="font-heading font-black text-4xl sm:text-6xl lg:text-7xl tracking-tight text-white leading-[1.1] mb-6">
          Smart Railway Passenger <br />
          <span className="bg-gradient-to-r from-blue-400 via-cyan-300 via-amber-300 to-emerald-400 bg-clip-text text-transparent drop-shadow-sm">
            Safety System
          </span>
        </h1>

        {/* Subheading */}
        <p className="max-w-3xl text-base sm:text-lg lg:text-xl text-slate-300 font-normal leading-relaxed mb-10">
          AI-Powered Safety Platform for Indian Railways that ensures passenger security through intelligent monitoring, real-time emergency response, predictive analytics, and smart communication.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full max-w-md mb-14">
          <button
            onClick={() => onSelectView('passenger')}
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-railway-blue via-blue-600 to-cyan-500 text-white font-bold text-sm tracking-wide shadow-xl shadow-railway-blue/40 hover:shadow-cyan-500/50 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 border border-cyan-400/30 group"
          >
            <span>Get Started</span>
            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform text-cyan-200" />
          </button>

          <button
            onClick={onOpenSos}
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-100 font-bold text-sm tracking-wide border border-rose-500/50 hover:border-rose-400 shadow-lg shadow-rose-900/20 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 group"
          >
            <Play size={16} className="text-rose-400 fill-rose-400/30 group-hover:scale-110 transition-transform" />
            <span>Test Live SOS Demo</span>
          </button>
        </div>

        {/* Animated Railway Track Visualizer */}
        <div className="relative w-full max-w-4xl h-24 my-4 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-slate-800/80 overflow-hidden flex items-center justify-center shadow-2xl">
          {/* Track sleepers */}
          <div className="absolute inset-0 flex justify-between px-2 items-center opacity-40">
            {Array.from({ length: 40 }).map((_, i) => (
              <div key={i} className="w-1.5 h-16 bg-slate-700 rounded-sm"></div>
            ))}
          </div>
          {/* Rails */}
          <div className="absolute w-full h-1 bg-cyan-500/60 top-6 shadow-[0_0_10px_#00e5ff]"></div>
          <div className="absolute w-full h-1 bg-cyan-500/60 bottom-6 shadow-[0_0_10px_#00e5ff]"></div>

          {/* Moving Train SVG Animation */}
          <div className="absolute left-0 animate-train-drive flex items-center gap-1 z-20">
            <div className="w-20 h-10 bg-gradient-to-r from-railway-blue to-cyan-500 rounded-r-2xl rounded-l-md flex items-center justify-between px-3 shadow-lg shadow-cyan-500/50 border border-cyan-300/40">
              <Train size={22} className="text-white animate-pulse" />
              <div className="w-3 h-3 rounded-full bg-amber-400 shadow-[0_0_8px_#ffb300]"></div>
            </div>
            <div className="w-16 h-9 bg-slate-800 rounded-md border border-slate-600 flex items-center justify-center">
              <span className="text-[9px] font-mono text-cyan-400 font-bold">B4 COACH</span>
            </div>
            <div className="w-16 h-9 bg-slate-800 rounded-md border border-slate-600 flex items-center justify-center">
              <span className="text-[9px] font-mono text-emerald-400 font-bold">B3 COACH</span>
            </div>
          </div>
        </div>

        {/* Statistics Bar Section */}
        <div className="w-full mt-10 grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          <div className="glass-card p-5 rounded-2xl border border-slate-800 hover:border-railway-cyan/40 text-center">
            <div className="text-3xl sm:text-4xl font-extrabold font-heading text-white mb-1 bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">
              50,000+
            </div>
            <div className="text-xs sm:text-sm font-medium text-slate-400">
              Passengers Protected
            </div>
          </div>

          <div className="glass-card p-5 rounded-2xl border border-slate-800 hover:border-amber-500/40 text-center">
            <div className="text-3xl sm:text-4xl font-extrabold font-heading text-white mb-1 bg-gradient-to-r from-amber-400 to-orange-300 bg-clip-text text-transparent">
              2,500+
            </div>
            <div className="text-xs sm:text-sm font-medium text-slate-400">
              Emergency Responses
            </div>
          </div>

          <div className="glass-card p-5 rounded-2xl border border-slate-800 hover:border-emerald-500/40 text-center">
            <div className="text-3xl sm:text-4xl font-extrabold font-heading text-white mb-1 bg-gradient-to-r from-emerald-400 to-teal-300 bg-clip-text text-transparent">
              98%
            </div>
            <div className="text-xs sm:text-sm font-medium text-slate-400">
              Response Accuracy
            </div>
          </div>

          <div className="glass-card p-5 rounded-2xl border border-slate-800 hover:border-purple-500/40 text-center">
            <div className="text-3xl sm:text-4xl font-extrabold font-heading text-white mb-1 bg-gradient-to-r from-purple-400 to-indigo-300 bg-clip-text text-transparent">
              700+
            </div>
            <div className="text-xs sm:text-sm font-medium text-slate-400">
              Railway Stations Connected
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
