import React from 'react';
import { 
  Smartphone, 
  Server, 
  KeyRound, 
  Cpu, 
  Database, 
  Zap, 
  Bell, 
  ShieldCheck, 
  Radio,
  ArrowDown,
  ArrowRight
} from 'lucide-react';

export const ArchitectureSection: React.FC = () => {
  const flowSteps = [
    {
      id: 1,
      title: "Passenger App & Edge IoT",
      desc: "Mobile App, Voice SOS, Onboard Cameras",
      icon: Smartphone,
      color: "bg-blue-500/20 text-blue-400 border-blue-500/40"
    },
    {
      id: 2,
      title: "Backend APIs & Mesh Gateway",
      desc: "Node.js Microservices & WebSocket Layer",
      icon: Server,
      color: "bg-cyan-500/20 text-cyan-400 border-cyan-500/40"
    },
    {
      id: 3,
      title: "Encrypted Auth & PNR Validation",
      desc: "JWT Auth, OAuth & DPDP Privacy Compliance",
      icon: KeyRound,
      color: "bg-indigo-500/20 text-indigo-400 border-indigo-500/40"
    },
    {
      id: 4,
      title: "Autonomous AI Engine",
      desc: "YOLOv8 Threat Detection & Audio Classification",
      icon: Cpu,
      color: "bg-purple-500/20 text-purple-400 border-purple-500/40"
    },
    {
      id: 5,
      title: "MongoDB & Vector Database",
      desc: "Geo-Spatial Telemetry & Blacklist Matches",
      icon: Database,
      color: "bg-emerald-500/20 text-emerald-400 border-emerald-500/40"
    },
    {
      id: 6,
      title: "Emergency Dispatch Engine",
      desc: "Nearest RPF Patrol Geo-Routing & Timer",
      icon: Zap,
      color: "bg-rose-500/20 text-rose-400 border-rose-500/40"
    },
    {
      id: 7,
      title: "Notification & FCM Service",
      desc: "Multi-channel Push, SMS Mesh & Siren Relay",
      icon: Bell,
      color: "bg-amber-500/20 text-amber-400 border-amber-500/40"
    },
    {
      id: 8,
      title: "Railway Police (RPF) Tactical Portal",
      desc: "Tablet Interface & On-Site Response Verification",
      icon: ShieldCheck,
      color: "bg-blue-600/20 text-blue-300 border-blue-400/40"
    },
    {
      id: 9,
      title: "National Control Room Dashboard",
      desc: "Pan-India Command Overview & CCTV Grid",
      icon: Radio,
      color: "bg-emerald-600/20 text-emerald-300 border-emerald-400/40"
    }
  ];

  return (
    <section id="architecture" className="py-20 bg-slate-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="px-3.5 py-1.5 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/30 text-xs font-semibold uppercase tracking-wider">
            High-Availability Pipeline Architecture
          </span>
          <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight">
            System <span className="text-purple-400">Architecture Diagram</span>
          </h2>
          <p className="mt-4 text-base text-slate-400">
            A resilient multi-tier framework ensuring zero data loss and sub-second dispatch latency across all Indian Railway zones.
          </p>
        </div>

        {/* Workflow Diagram Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-6">
          {flowSteps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={step.id} className="relative group">
                <div className="glass-card p-6 rounded-3xl border border-slate-800 hover:border-purple-500/50 bg-gradient-to-b from-slate-950 to-slate-900 h-full flex flex-col justify-between transition-all group-hover:-translate-y-1">
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <div className={`p-3.5 rounded-2xl border ${step.color}`}>
                        <Icon size={24} />
                      </div>
                      <span className="font-mono text-xs font-extrabold text-slate-500">
                        STAGE 0{step.id}
                      </span>
                    </div>

                    <h3 className="text-lg font-bold font-heading text-white mb-1">{step.title}</h3>
                    <p className="text-xs text-slate-400">{step.desc}</p>
                  </div>

                  <div className="mt-6 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-500">
                    <span>Verified Protocol</span>
                    <ArrowRight size={14} className="text-purple-400 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
