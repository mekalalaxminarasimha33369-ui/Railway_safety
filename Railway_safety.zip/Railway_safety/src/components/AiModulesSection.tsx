import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Crosshair, 
  Briefcase, 
  Volume2, 
  TrendingUp, 
  MessageSquare, 
  ScanFace, 
  Eye, 
  Cpu, 
  Sparkles,
  Play,
  CheckCircle,
  Activity
} from 'lucide-react';
import { mockAiModules } from '../data/mockData';

export const AiModulesSection: React.FC = () => {
  const [simulatingThreat, setSimulatingThreat] = useState<boolean>(false);
  const [simResult, setSimResult] = useState<{
    threatType: string;
    confidence: number;
    bbox: string;
    action: string;
  } | null>(null);

  const runAiSimulation = () => {
    setSimulatingThreat(true);
    setSimResult(null);
    setTimeout(() => {
      setSimulatingThreat(false);
      setSimResult({
        threatType: 'Unattended Baggage (>5 min) + Distress Decibel Peak',
        confidence: 98.4,
        bbox: '[X: 420, Y: 180, W: 110, H: 85]',
        action: 'Auto-Triggered RPF Patrol Unit #4 Dispatch & Camera Zoom'
      });
    }, 1500);
  };

  return (
    <section id="ai-modules" className="py-20 bg-slate-950 relative overflow-hidden">
      
      {/* Background Grid Accent */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="px-3.5 py-1.5 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/30 text-xs font-semibold uppercase tracking-wider">
            Autonomous Computer Vision & Audio AI
          </span>
          <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight">
            Core <span className="bg-gradient-to-r from-purple-400 via-indigo-300 to-cyan-400 bg-clip-text text-transparent">AI Safety Engine</span>
          </h2>
          <p className="mt-4 text-base text-slate-400">
            Powered by state-of-the-art Deep Learning models optimized for high-fps edge inference inside moving train coaches and high-density station platforms.
          </p>
        </div>

        {/* AI Modules Showcase Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {mockAiModules.map((item) => (
            <div
              key={item.id}
              className="glass-card p-6 rounded-3xl border border-purple-900/40 hover:border-purple-500/60 bg-gradient-to-b from-slate-900/90 via-slate-900/60 to-slate-950 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 rounded-2xl bg-purple-500/10 text-purple-400 border border-purple-500/30">
                    <Cpu size={22} />
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold bg-slate-800 text-purple-300 border border-purple-400/30">
                    {item.category}
                  </span>
                </div>

                <h3 className="text-lg font-bold font-heading text-white mb-2">{item.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed mb-4">{item.description}</p>
              </div>

              <div className="pt-4 border-t border-slate-800/80 grid grid-cols-3 gap-2 text-[10px] font-mono">
                <div>
                  <div className="text-slate-500">Accuracy</div>
                  <div className="text-emerald-400 font-bold">{item.accuracy}</div>
                </div>
                <div>
                  <div className="text-slate-500">Latency</div>
                  <div className="text-cyan-400 font-bold">{item.latency}</div>
                </div>
                <div>
                  <div className="text-slate-500">Engine</div>
                  <div className="text-purple-300 truncate">{item.tech.split(' ')[0]}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Live Interactive AI Vision Simulator Tool */}
        <div className="glass-card p-8 rounded-3xl border border-purple-500/40 bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 shadow-2xl relative overflow-hidden">
          
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            
            <div className="max-w-xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-semibold mb-3">
                <Sparkles size={14} className="text-amber-400" />
                <span>Interactive AI Threat Detector Testbench</span>
              </div>
              <h3 className="text-2xl font-bold font-heading text-white">
                Test SafeRail AI Vision & Threat Neural Net
              </h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Click below to feed a simulated live 1080p CCTV feed frame from Coach B4 into the YOLOv8 + Audio MFCC inference engine.
              </p>

              <div className="mt-6 flex items-center gap-4">
                <button
                  onClick={runAiSimulation}
                  disabled={simulatingThreat}
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-purple-600/30 flex items-center gap-2 border border-purple-400/40 disabled:opacity-50"
                >
                  {simulatingThreat ? (
                    <>
                      <Activity size={16} className="animate-spin text-amber-400" />
                      <span>Running Inference...</span>
                    </>
                  ) : (
                    <>
                      <Play size={16} className="text-white fill-white/20" />
                      <span>Run AI Frame Inference Test</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Mock Camera Screen with Bounding Box Overlay */}
            <div className="w-full lg:w-96 h-56 bg-slate-950 rounded-2xl border border-purple-500/40 relative overflow-hidden flex flex-col justify-between p-3 shadow-inner">
              
              {/* Screen Top Overlay */}
              <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 z-10">
                <span className="flex items-center gap-1.5 text-rose-400 font-bold">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                  LIVE CAM-TB-12423-B4
                </span>
                <span>30.0 FPS &bull; 1080p</span>
              </div>

              {/* Bounding Box Render */}
              {simulatingThreat && (
                <div className="absolute inset-0 flex items-center justify-center bg-slate-950/80 z-20">
                  <div className="text-center font-mono">
                    <Activity size={28} className="animate-spin text-purple-400 mx-auto mb-2" />
                    <div className="text-xs text-purple-300">Extracting Feature Map...</div>
                  </div>
                </div>
              )}

              {simResult && (
                <div className="absolute top-12 left-10 w-44 h-28 border-2 border-amber-400 bg-amber-500/10 rounded p-1.5 text-[9px] font-mono text-amber-300 z-10 animate-pulse">
                  <div className="font-bold flex items-center justify-between">
                    <span>ALERT: ANOMALY</span>
                    <span>{simResult.confidence}%</span>
                  </div>
                  <div className="text-[8px] text-amber-200 mt-1">
                    {simResult.threatType}
                  </div>
                </div>
              )}

              {/* Screen Bottom Overlay */}
              <div className="z-10 bg-slate-900/90 p-2 rounded-xl border border-slate-800 text-[10px] font-mono">
                {simResult ? (
                  <div className="text-emerald-400 font-bold flex items-center gap-1.5">
                    <CheckCircle size={12} />
                    <span>Action: {simResult.action}</span>
                  </div>
                ) : (
                  <div className="text-slate-400">
                    Status: Standing by for inference run...
                  </div>
                )}
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
