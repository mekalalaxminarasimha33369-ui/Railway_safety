import React from 'react';
import { 
  AlertTriangle, 
  CheckCircle2, 
  ShieldCheck, 
  Clock, 
  UserX, 
  HeartPulse, 
  Cpu, 
  Radio, 
  MapPin, 
  Lock,
  ArrowRight
} from 'lucide-react';

export const AboutSection: React.FC = () => {
  const problems = [
    {
      title: "Coach & Station Crimes",
      desc: "Theft, harassment, and unauthorized entry often go undetected in long-distance sleeper and unreserved coaches.",
      icon: AlertTriangle,
      color: "text-rose-400"
    },
    {
      title: "Delayed Medical Response",
      desc: "Passengers experiencing sudden cardiac or medical crises during transit face critical delay before reaching medical help.",
      icon: HeartPulse,
      color: "text-rose-400"
    },
    {
      title: "Missing Passengers & Children",
      desc: "Children or vulnerable travelers getting separated at crowded stations without immediate facial tracking.",
      icon: UserX,
      color: "text-rose-400"
    },
    {
      title: "Fragmented Emergency Chains",
      desc: "Lack of direct real-time GPS link between passenger mobile devices and nearest patrolling RPF squad officers.",
      icon: Clock,
      color: "text-rose-400"
    }
  ];

  const solutions = [
    {
      title: "Edge-AI Computer Vision",
      desc: "Real-time anomaly, unattended baggage, and facial recognition models processing live camera feeds directly at stations.",
      icon: Cpu,
      color: "text-cyan-400"
    },
    {
      title: "One-Tap Precision SOS",
      desc: "Instant carriage-level location relay (Train, Coach, Seat) with live GPS stream directly to onboard RPF squad.",
      icon: Radio,
      color: "text-amber-400"
    },
    {
      title: "Predictive Crime Analytics",
      desc: "Spatial machine learning models forecasting vulnerable route sections and automatically deploying patrol forces.",
      icon: ShieldCheck,
      color: "text-emerald-400"
    },
    {
      title: "Unified National Command Grid",
      desc: "Centralized RPF control room dashboard connecting 700+ major junctions, divisional hubs, and running express trains.",
      icon: Lock,
      color: "text-indigo-400"
    }
  ];

  return (
    <section id="about" className="py-20 bg-slate-900 relative overflow-hidden">
      
      {/* Subtle Background Glow */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-railway-blue/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="px-3.5 py-1.5 rounded-full bg-railway-blue/20 text-railway-cyan border border-railway-cyan/30 text-xs font-semibold uppercase tracking-wider">
            Transforming Indian Railways Security
          </span>
          <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight">
            The Safety Challenge & <span className="text-amber-400">SafeRail AI</span> Solution
          </h2>
          <p className="mt-4 text-base text-slate-300">
            Indian Railways carries over 23 million passengers daily across 67,000+ km of tracks. Modernizing security requires bridging legacy monitoring gaps with next-generation artificial intelligence.
          </p>
        </div>

        {/* Comparison Grid: Problem vs Solution */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
          
          {/* Current Problem Card Container */}
          <div className="glass-card p-8 rounded-3xl border border-rose-950/60 bg-gradient-to-b from-rose-950/20 via-slate-900 to-slate-950 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-6 border-b border-rose-900/40 pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400">
                    <AlertTriangle size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold font-heading text-white">Current Railway Safety Challenges</h3>
                    <p className="text-xs text-rose-300/80 font-mono">Legacy Manual Response Gaps</p>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded bg-rose-950 text-rose-400 border border-rose-800 text-[10px] font-mono font-bold">
                  CRITICAL GAP
                </span>
              </div>

              <div className="space-y-4">
                {problems.map((item, idx) => (
                  <div key={idx} className="p-4 rounded-2xl bg-slate-950/60 border border-rose-900/30 flex items-start gap-3">
                    <item.icon className={`${item.color} mt-1 shrink-0`} size={18} />
                    <div>
                      <h4 className="text-sm font-bold text-slate-200">{item.title}</h4>
                      <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8 p-4 rounded-2xl bg-rose-950/40 border border-rose-800/40 text-xs text-rose-200 flex items-center justify-between">
              <span>Impact: Higher passenger anxiety during night travel</span>
              <span className="font-bold text-rose-400 font-mono">Unresolved Risk</span>
            </div>
          </div>

          {/* SafeRail AI Solution Card Container */}
          <div className="glass-card p-8 rounded-3xl border border-cyan-900/60 bg-gradient-to-b from-railway-blue/20 via-slate-900 to-slate-950 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-6 border-b border-cyan-900/40 pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-2xl bg-railway-cyan/10 border border-railway-cyan/30 text-railway-cyan">
                    <CheckCircle2 size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold font-heading text-white">The SafeRail AI Architecture</h3>
                    <p className="text-xs text-cyan-300/80 font-mono">Next-Gen Intelligent Defense</p>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded bg-cyan-950 text-railway-cyan border border-cyan-800 text-[10px] font-mono font-bold">
                  AI SOLUTION
                </span>
              </div>

              <div className="space-y-4">
                {solutions.map((item, idx) => (
                  <div key={idx} className="p-4 rounded-2xl bg-slate-950/60 border border-cyan-900/30 flex items-start gap-3 hover:border-cyan-500/40 transition-colors">
                    <item.icon className={`${item.color} mt-1 shrink-0`} size={18} />
                    <div>
                      <h4 className="text-sm font-bold text-slate-200">{item.title}</h4>
                      <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8 p-4 rounded-2xl bg-cyan-950/40 border border-cyan-800/40 text-xs text-cyan-200 flex items-center justify-between">
              <span>Result: Sub-3 minute average emergency RPF dispatch</span>
              <span className="font-bold text-emerald-400 font-mono">98% Accuracy</span>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
