import React, { useState } from 'react';
import { 
  User, 
  Shield, 
  Radio, 
  Settings, 
  Play, 
  Activity, 
  MapPin, 
  AlertTriangle, 
  CheckCircle,
  Eye,
  SlidersHorizontal,
  ArrowRight
} from 'lucide-react';
import { AppView } from '../types';

interface DashboardPreviewProps {
  onSelectView: (view: AppView) => void;
}

export const DashboardPreviewSection: React.FC<DashboardPreviewProps> = ({ onSelectView }) => {
  const [activeTab, setActiveTab] = useState<'rpf' | 'passenger' | 'control_room' | 'admin'>('rpf');

  return (
    <section id="dashboards-preview" className="py-20 bg-slate-950 relative overflow-hidden">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="px-3.5 py-1.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 text-xs font-semibold uppercase tracking-wider">
            Interactive Operational Control Centers
          </span>
          <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight">
            Live <span className="bg-gradient-to-r from-cyan-400 to-amber-400 bg-clip-text text-transparent">Dashboard Systems</span>
          </h2>
          <p className="mt-4 text-base text-slate-400">
            Explore dedicated command interfaces customized for passengers, patrolling RPF officers, station administrators, and national control rooms.
          </p>
        </div>

        {/* Dashboard Role Selector Switcher */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-10">
          <button
            onClick={() => setActiveTab('rpf')}
            className={`px-5 py-3 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 border ${
              activeTab === 'rpf'
                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg shadow-amber-500/20'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
            }`}
          >
            <Shield size={16} />
            <span>RPF Tactical Command</span>
          </button>

          <button
            onClick={() => setActiveTab('passenger')}
            className={`px-5 py-3 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 border ${
              activeTab === 'passenger'
                ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-lg shadow-cyan-500/20'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
            }`}
          >
            <User size={16} />
            <span>Passenger Portal</span>
          </button>

          <button
            onClick={() => setActiveTab('control_room')}
            className={`px-5 py-3 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 border ${
              activeTab === 'control_room'
                ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-lg shadow-emerald-500/20'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
            }`}
          >
            <Radio size={16} />
            <span>National Control Room</span>
          </button>

          <button
            onClick={() => setActiveTab('admin')}
            className={`px-5 py-3 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 border ${
              activeTab === 'admin'
                ? 'bg-purple-500 text-slate-950 border-purple-400 shadow-lg shadow-purple-500/20'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
            }`}
          >
            <Settings size={16} />
            <span>Admin & Analytics</span>
          </button>
        </div>

        {/* Dashboard Mockup Frame */}
        <div className="glass-card rounded-3xl border border-slate-800 overflow-hidden shadow-2xl bg-slate-950">
          
          {/* Top Mock Window Bar */}
          <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-rose-500"></div>
              <div className="w-3 h-3 rounded-full bg-amber-500"></div>
              <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
              <span className="ml-3 font-mono text-xs text-slate-400">
                https://saferail.railways.gov.in/{activeTab}-portal
              </span>
            </div>

            <button
              onClick={() => onSelectView(activeTab as AppView)}
              className="px-4 py-1.5 rounded-xl bg-railway-blue hover:bg-blue-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-md"
            >
              <span>Launch Live Interactive Portal</span>
              <ArrowRight size={14} />
            </button>
          </div>

          {/* Interactive Mock Content Screen */}
          <div className="p-6 md:p-8 bg-slate-950">
            {activeTab === 'rpf' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-800 text-rose-300">
                    <div className="text-xs font-mono">ACTIVE EMERGENCY QUEUE</div>
                    <div className="text-2xl font-bold font-mono mt-1 text-white">03 CRITICAL</div>
                  </div>
                  <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-800 text-amber-300">
                    <div className="text-xs font-mono font-bold">AVG RPF RESPONSE TIMER</div>
                    <div className="text-2xl font-bold font-mono mt-1 text-white">02m 45s</div>
                  </div>
                  <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-800 text-emerald-300">
                    <div className="text-xs font-mono">ON-DUTY SQUADS</div>
                    <div className="text-2xl font-bold font-mono mt-1 text-white">48 OFFICERS ACTIVE</div>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                  <div className="text-xs font-mono text-slate-400 mb-3 uppercase tracking-wider">Live SOS Alert Payload</div>
                  <div className="p-4 rounded-xl bg-slate-950 border border-rose-500/50 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="p-3 rounded-xl bg-rose-500/20 text-rose-400">
                        <AlertTriangle size={24} />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-white">ALT-9042: Women Passenger Harassment Alert</div>
                        <div className="text-xs text-slate-400">Train 12423 (Rajdhani) &bull; Coach B4 &bull; Seat 32 &bull; Ananya Sharma</div>
                      </div>
                    </div>
                    <button 
                      onClick={() => onSelectView('rpf')}
                      className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shrink-0"
                    >
                      Dispatch Nearest Unit
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'passenger' && (
              <div className="space-y-6">
                <div className="p-6 rounded-2xl bg-gradient-to-r from-railway-blue/40 to-cyan-900/40 border border-cyan-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div>
                    <span className="px-2.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-xs font-mono font-bold">
                      ACTIVE JOURNEY VERIFIED
                    </span>
                    <h3 className="text-xl font-bold text-white mt-1">Train 12423 - RAJDHANI EXPRESS</h3>
                    <p className="text-xs text-slate-300 mt-1">New Delhi (NDLS) &rarr; Dibrugarh (DBRG) | Coach B4, Seat 32</p>
                  </div>
                  <button 
                    onClick={() => onSelectView('passenger')}
                    className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs shadow-lg shadow-red-600/30 flex items-center gap-2"
                  >
                    <AlertTriangle size={16} />
                    <span>Open Passenger Emergency SOS</span>
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'control_room' && (
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between text-xs font-mono text-slate-300">
                  <span>NATIONAL COMMAND MAP OVERVIEW &bull; 750 STATIONS CONNECTED</span>
                  <span className="text-emerald-400 font-bold">SYSTEM HEALTH: 100% ONLINE</span>
                </div>
                <div className="h-44 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center text-slate-500 font-mono text-xs">
                  [ Interactive High-Tech Geographic Map Visualizer & Live CCTV Grid Active ]
                </div>
              </div>
            )}

            {activeTab === 'admin' && (
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between text-xs font-mono text-slate-300">
                  <span>SYSTEM LOGS & AI CONFIDENCE METRICS</span>
                  <span className="text-purple-400 font-bold">YOLOv8 INFERENCE: 99.2%</span>
                </div>
                <div className="h-44 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center text-slate-500 font-mono text-xs">
                  [ System Configuration, User Access Control & Crime Analytics Logs ]
                </div>
              </div>
            )}
          </div>

        </div>

      </div>
    </section>
  );
};
