import React from 'react';
import { Building2, MapPin, Users, ShieldAlert, Award } from 'lucide-react';

export const ImpactSection: React.FC = () => {
  const stats = [
    { label: "Cities Covered", value: "100+", icon: Building2, color: "text-blue-400" },
    { label: "Railway Stations Connected", value: "750+", icon: MapPin, color: "text-cyan-400" },
    { label: "Passengers Protected Daily", value: "50,000+", icon: Users, color: "text-emerald-400" },
    { label: "Emergencies Handled", value: "2,500+", icon: ShieldAlert, color: "text-amber-400" },
    { label: "Emergency Success Rate", value: "99%", icon: Award, color: "text-purple-400" }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-slate-900 to-slate-950 border-y border-slate-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="px-3.5 py-1.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-semibold uppercase tracking-wider">
            Quantifiable National Footprint
          </span>
          <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight">
            Our <span className="text-emerald-400">Proven Impact</span>
          </h2>
          <p className="mt-4 text-base text-slate-400">
            Delivering safety, speed, and trust across major Indian Railway networks.
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-5 gap-6">
          {stats.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="glass-card p-6 rounded-3xl border border-slate-800 hover:border-emerald-500/40 text-center flex flex-col items-center justify-between"
              >
                <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 mb-4">
                  <Icon size={24} className={item.color} />
                </div>
                <div className="text-3xl sm:text-4xl font-extrabold font-heading text-white mb-1 bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
                  {item.value}
                </div>
                <div className="text-xs font-medium text-slate-400">
                  {item.label}
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
