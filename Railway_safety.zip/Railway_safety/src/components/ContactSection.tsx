import React, { useState } from 'react';
import { 
  PhoneCall, 
  Mail, 
  MapPin, 
  Building2, 
  Send, 
  CheckCircle,
  Twitter,
  Facebook,
  Linkedin,
  Youtube
} from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'General Security Inquiry',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ name: '', email: '', phone: '', subject: 'General Security Inquiry', message: '' });
    }, 4000);
  };

  return (
    <section id="contact" className="py-20 bg-slate-950 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="px-3.5 py-1.5 rounded-full bg-railway-blue/20 text-cyan-400 border border-cyan-500/30 text-xs font-semibold uppercase tracking-wider">
            Command Center & Support Helpline
          </span>
          <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight">
            Connect with <span className="text-amber-400">SafeRail AI Team</span>
          </h2>
          <p className="mt-4 text-base text-slate-400">
            For railway divisional integrations, technical inquiries, or emergency RPF support.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          
          {/* Contact Details & HQ Map Card */}
          <div className="space-y-6">
            <div className="glass-card p-8 rounded-3xl border border-slate-800 bg-slate-900 space-y-6">
              <h3 className="text-xl font-bold font-heading text-white">Railway Board & RPF Headquarters</h3>

              <div className="space-y-4 text-sm text-slate-300">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-xl bg-railway-blue/20 text-cyan-400 shrink-0">
                    <Building2 size={18} />
                  </div>
                  <div>
                    <div className="font-bold text-white">Ministry of Railways (Rail Bhavan)</div>
                    <div className="text-xs text-slate-400">Raisina Road, New Delhi - 110001, India</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 shrink-0">
                    <PhoneCall size={18} />
                  </div>
                  <div>
                    <div className="font-bold text-white">National RPF Emergency Helpline</div>
                    <div className="text-xs text-amber-400 font-mono font-bold">139 (Toll-Free 24x7)</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-400 shrink-0">
                    <Mail size={18} />
                  </div>
                  <div>
                    <div className="font-bold text-white">Support & SIH Inquiries</div>
                    <div className="text-xs text-slate-400">saferail.support@railnet.gov.in</div>
                  </div>
                </div>
              </div>

              {/* Social Media Links */}
              <div className="pt-6 border-t border-slate-800 flex items-center gap-4 text-slate-400">
                <span className="text-xs font-semibold">Official Handles:</span>
                <div className="flex items-center gap-3">
                  <a href="#" className="p-2 rounded-lg bg-slate-800 hover:text-cyan-400 hover:bg-slate-700 transition-colors">
                    <Twitter size={16} />
                  </a>
                  <a href="#" className="p-2 rounded-lg bg-slate-800 hover:text-cyan-400 hover:bg-slate-700 transition-colors">
                    <Facebook size={16} />
                  </a>
                  <a href="#" className="p-2 rounded-lg bg-slate-800 hover:text-cyan-400 hover:bg-slate-700 transition-colors">
                    <Linkedin size={16} />
                  </a>
                  <a href="#" className="p-2 rounded-lg bg-slate-800 hover:text-cyan-400 hover:bg-slate-700 transition-colors">
                    <Youtube size={16} />
                  </a>
                </div>
              </div>
            </div>

            {/* Map Frame Visualizer */}
            <div className="h-56 rounded-3xl bg-slate-900 border border-slate-800 overflow-hidden relative flex items-center justify-center">
              <div className="absolute inset-0 bg-cyber-grid opacity-30"></div>
              <div className="text-center z-10 font-mono text-xs text-slate-400">
                <MapPin size={28} className="text-rose-500 mx-auto mb-2 animate-bounce" />
                <div className="font-bold text-white">Rail Bhavan, New Delhi (28.6186° N, 77.2155° E)</div>
                <div className="text-[10px] text-slate-500">Live Geo-Fenced Command Node</div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="glass-card p-8 rounded-3xl border border-slate-800 bg-slate-900">
            <h3 className="text-xl font-bold font-heading text-white mb-2">Send Official Message</h3>
            <p className="text-xs text-slate-400 mb-6">Fill out the form below to reach the SafeRail AI technical architecture panel.</p>

            {submitted ? (
              <div className="p-6 rounded-2xl bg-emerald-500/10 border border-emerald-500/40 text-center text-emerald-400 space-y-2">
                <CheckCircle size={36} className="mx-auto" />
                <div className="font-bold text-lg">Message Transmitted Successfully</div>
                <div className="text-xs text-emerald-300">Your inquiry ticket has been registered with Rail Bhavan Security Control.</div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Full Name</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Ramesh Kumar"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:border-cyan-400 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Official Email</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="name@railnet.gov.in"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:border-cyan-400 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Mobile / PNR</label>
                    <input
                      type="text"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+91 98765 43210"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:border-cyan-400 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Subject</label>
                    <select
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:border-cyan-400 focus:outline-none"
                    >
                      <option>General Security Inquiry</option>
                      <option>SIH Project Evaluation</option>
                      <option>RPF Deployment Request</option>
                      <option>Crime / Misconduct Report</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Message</label>
                  <textarea
                    rows={4}
                    required
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Provide details about your query..."
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:border-cyan-400 focus:outline-none"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-railway-blue to-cyan-500 hover:from-blue-600 hover:to-cyan-400 text-white font-bold text-xs shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2"
                >
                  <Send size={16} />
                  <span>Transmit Inquiry Ticket</span>
                </button>
              </form>
            )}
          </div>

        </div>

      </div>
    </section>
  );
};
