import React from 'react';
import { 
  ShieldCheck, 
  Heart, 
  UserCheck, 
  Baby, 
  HeartPulse, 
  Moon, 
  Train, 
  Building2, 
  Camera,
  ArrowRight
} from 'lucide-react';
import { AppView } from '../types';

interface SafetyProps {
  onSelectView: (view: AppView) => void;
}

export const SafetyModulesSection: React.FC<SafetyProps> = ({ onSelectView }) => {
  const modules = [
    {
      title: "Women Passenger Safety",
      badge: "Priority #1",
      desc: "Specialized night travel tracking, female RPF officer squad pairing, and one-tap voice trigger SOS.",
      icon: ShieldCheck,
      color: "from-pink-500 to-rose-600",
      accent: "text-pink-400"
    },
    {
      title: "Senior Citizen Escort",
      badge: "Assistance",
      desc: "Priority porter assistance booking, wheelchair dispatch at platform, and medical health parameter alerts.",
      icon: UserCheck,
      color: "from-amber-500 to-orange-600",
      accent: "text-amber-400"
    },
    {
      title: "Child Security & Lost Match",
      badge: "Biometric AI",
      desc: "Continuous facial surveillance at station exits to prevent child separation and trafficking.",
      icon: Baby,
      color: "from-purple-500 to-indigo-600",
      accent: "text-purple-400"
    },
    {
      title: "Medical Emergency Response",
      badge: "24/7 Hotline",
      desc: "Automated alert dispatch to upcoming station medical bay with doctor standby at carriage arrival.",
      icon: HeartPulse,
      color: "from-rose-500 to-red-600",
      accent: "text-rose-400"
    },
    {
      title: "Night Travel Escort Guard",
      badge: "Active Patrol",
      desc: "Automated lighting status check in sleeper coaches and mandatory RPF night patrol check-ins.",
      icon: Moon,
      color: "from-blue-600 to-cyan-600",
      accent: "text-cyan-400"
    },
    {
      title: "Smart Coach Monitoring",
      badge: "IoT Node",
      desc: "Vibration, smoke, acoustic, and temperature sensors transmitting telemetry to train guard room.",
      icon: Train,
      color: "from-emerald-500 to-teal-600",
      accent: "text-emerald-400"
    },
    {
      title: "Platform Overcrowding Alert",
      badge: "Density AI",
      desc: "Crowd density analysis preventing stampedes on foot overbridges (FOBs) during festive rush.",
      icon: Building2,
      color: "from-indigo-500 to-blue-600",
      accent: "text-indigo-400"
    },
    {
      title: "360° Station Surveillance",
      badge: "750+ Hubs",
      desc: "Multi-camera stitched panoramic views for station master and divisional security control.",
      icon: Camera,
      color: "from-cyan-500 to-blue-600",
      accent: "text-cyan-400"
    }
  ];

  return (
    <section className="py-20 bg-slate-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="px-3.5 py-1.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-semibold uppercase tracking-wider">
            Tailored Passenger Protection
          </span>
          <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight">
            Specialized <span className="text-emerald-400">Safety Modules</span>
          </h2>
          <p className="mt-4 text-base text-slate-400">
            Dedicated protocols and automated safeguards designed for every demographic of Indian Railway commuters.
          </p>
        </div>

        {/* Modules Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {modules.map((mod, idx) => {
            const Icon = mod.icon;
            return (
              <div
                key={idx}
                className="glass-card group p-6 rounded-3xl border border-slate-800 hover:border-emerald-500/50 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-2xl bg-gradient-to-br ${mod.color} text-white shadow-lg group-hover:scale-110 transition-transform`}>
                      <Icon size={22} />
                    </div>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-slate-800 text-slate-300 border border-slate-700">
                      {mod.badge}
                    </span>
                  </div>

                  <h3 className="text-base font-bold font-heading text-white mb-2 group-hover:text-emerald-300 transition-colors">
                    {mod.title}
                  </h3>

                  <p className="text-xs text-slate-400 leading-relaxed">
                    {mod.desc}
                  </p>
                </div>

                <button
                  onClick={() => onSelectView('passenger')}
                  className="mt-6 flex items-center gap-1.5 text-xs font-semibold text-slate-300 group-hover:text-emerald-400 transition-colors"
                >
                  <span>Explore Protection Protocol</span>
                  <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
