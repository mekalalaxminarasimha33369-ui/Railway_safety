export type AppView = 'home' | 'passenger' | 'rpf' | 'admin' | 'control_room';

export type Language = 'EN' | 'HI' | 'TA' | 'TE' | 'BN' | 'MR';

export interface EmergencyAlert {
  id: string;
  passengerName: string;
  phone: string;
  trainNo: string;
  trainName: string;
  coach: string;
  seat: string;
  location: string;
  lat: number;
  lng: number;
  timestamp: string;
  type: 'Medical' | 'Women Security' | 'Theft/Crime' | 'Child Safety' | 'General Threat';
  status: 'CRITICAL' | 'DISPATCHED' | 'ON_SITE' | 'RESOLVED';
  confidence: number;
  aiDetected: boolean;
}

export interface JourneyDetails {
  pnr: string;
  trainNo: string;
  trainName: string;
  source: string;
  destination: string;
  coach: string;
  seatNo: string;
  departureTime: string;
  arrivalTime: string;
  currentStation: string;
  nextStation: string;
  status: 'ON_TIME' | 'DELAYED' | 'ARRIVING_SOON';
  safetyScore: number;
}

export interface CctvFeed {
  id: string;
  stationOrTrain: string;
  cameraLocation: string;
  status: 'ACTIVE' | 'WARNING' | 'ALERT';
  aiAlert?: string;
  peopleCount: number;
  threatLevel: 'Low' | 'Medium' | 'High';
  fps: number;
}

export interface AiModuleItem {
  id: string;
  title: string;
  category: 'Vision' | 'Audio' | 'Predictive' | 'NLP';
  description: string;
  icon: string;
  accuracy: string;
  latency: string;
  tech: string;
}

export interface FeatureItem {
  id: string;
  title: string;
  category: 'Passenger' | 'RPF' | 'AI Surveillance' | 'Safety';
  description: string;
  iconName: string;
  gradient: string;
  badge?: string;
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  organization: string;
  quote: string;
  avatar: string;
  rating: number;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}
