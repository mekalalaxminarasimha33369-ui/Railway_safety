import React, { useState, useEffect } from 'react';
import { AppView } from './types';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { FeaturesSection } from './components/FeaturesSection';
import { HowItWorks } from './components/HowItWorks';
import { AiModulesSection } from './components/AiModulesSection';
import { SafetyModulesSection } from './components/SafetyModulesSection';
import { TechStackSection } from './components/TechStackSection';
import { ArchitectureSection } from './components/ArchitectureSection';
import { DashboardPreviewSection } from './components/DashboardPreviewSection';
import { AnalyticsSection } from './components/AnalyticsSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { ImpactSection } from './components/ImpactSection';
import { FaqSection } from './components/FaqSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';

import { ScrollProgressBar } from './components/common/ScrollProgressBar';
import { SosModal } from './components/common/SosModal';
import { AiChatbotModal } from './components/common/AiChatbotModal';
import { QrCodeModal } from './components/common/QrCodeModal';
import { ReportCrimeModal } from './components/common/ReportCrimeModal';
import { DashboardContainer } from './dashboards/DashboardContainer';

export function App() {
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);

  // Modals
  const [isSosOpen, setIsSosOpen] = useState<boolean>(false);
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [isQrOpen, setIsQrOpen] = useState<boolean>(false);
  const [isReportOpen, setIsReportOpen] = useState<boolean>(false);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  return (
    <div className={`min-h-screen font-sans ${isDarkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      
      {/* Top Scroll Indicator */}
      <ScrollProgressBar />

      {/* Main Website Navigation Bar */}
      <Navbar
        currentView={currentView}
        setCurrentView={setCurrentView}
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
        onOpenSos={() => setIsSosOpen(true)}
        onOpenChat={() => setIsChatOpen(true)}
      />

      {/* Main Content Area */}
      {currentView === 'home' ? (
        <main>
          <Hero
            onOpenSos={() => setIsSosOpen(true)}
            onSelectView={setCurrentView}
          />

          <AboutSection />

          <FeaturesSection />

          <HowItWorks />

          <AiModulesSection />

          <SafetyModulesSection
            onSelectView={setCurrentView}
          />

          <TechStackSection />

          <ArchitectureSection />

          <DashboardPreviewSection
            onSelectView={setCurrentView}
          />

          <AnalyticsSection />

          <TestimonialsSection />

          <ImpactSection />

          <FaqSection />

          <ContactSection />

          <Footer
            onSelectView={setCurrentView}
          />
        </main>
      ) : (
        <DashboardContainer
          currentView={currentView}
          setCurrentView={setCurrentView}
          onOpenSos={() => setIsSosOpen(true)}
          onOpenQr={() => setIsQrOpen(true)}
          onOpenReport={() => setIsReportOpen(true)}
        />
      )}

      {/* Modals & Floating Action Triggers */}
      <SosModal
        isOpen={isSosOpen}
        onClose={() => setIsSosOpen(false)}
      />

      <AiChatbotModal
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        onOpenSos={() => setIsSosOpen(true)}
      />

      <QrCodeModal
        isOpen={isQrOpen}
        onClose={() => setIsQrOpen(false)}
      />

      <ReportCrimeModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
      />

    </div>
  );
}

export default App;
