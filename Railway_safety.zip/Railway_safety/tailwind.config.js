/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        railway: {
          blue: '#005BAC',
          darkBlue: '#003D75',
          navy: '#0B1E36',
          darker: '#060D17',
          orange: '#FF8C00',
          green: '#00C853',
          red: '#D32F2F',
          cyan: '#00E5FF',
          gold: '#FFB300'
        }
      },
      fontFamily: {
        sans: ['Inter', 'Poppins', 'sans-serif'],
        heading: ['Poppins', 'Montserrat', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace']
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'track-move': 'trackMove 2s linear infinite',
        'train-drive': 'trainDrive 8s ease-in-out infinite',
        'float': 'float 4s ease-in-out infinite',
        'glow-pulse': 'glowPulse 2s ease-in-out infinite alternate',
        'radar-spin': 'radarSpin 4s linear infinite',
      },
      keyframes: {
        trackMove: {
          '0%': { transform: 'translateX(0)' },
          '100%': { transform: 'translateX(-100px)' },
        },
        trainDrive: {
          '0%': { transform: 'translateX(-100%)' },
          '50%': { transform: 'translateX(10%)' },
          '100%': { transform: 'translateX(120%)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        glowPulse: {
          '0%': { boxShadow: '0 0 15px rgba(0, 229, 255, 0.3)' },
          '100%': { boxShadow: '0 0 35px rgba(0, 229, 255, 0.8), 0 0 50px rgba(0, 91, 172, 0.5)' },
        },
        radarSpin: {
          '0%': { transform: 'rotate(0deg)' },
          '100%': { transform: 'rotate(360deg)' },
        }
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'cyber-grid': 'linear-gradient(to right, rgba(255, 255, 255, 0.05) 1px, transparent 1px), linear-gradient(to bottom, rgba(255, 255, 255, 0.05) 1px, transparent 1px)',
      }
    },
  },
  plugins: [],
}
